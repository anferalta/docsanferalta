-- Backup gerado via PDO
-- Data: 2026-09-23 20:33:54



-- Estrutura da tabela `auditoria`
CREATE TABLE `auditoria` (
  `id` int NOT NULL AUTO_INCREMENT,
  `utilizador_id` int DEFAULT NULL,
  `acao` varchar(255) NOT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `detalhes` text,
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_auditoria_user` (`utilizador_id`)
) ENGINE=MyISAM AUTO_INCREMENT=157 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dados da tabela `auditoria`
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('1','3','logout','95.92.119.110',NULL,'2026-09-03 14:22:00');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('2','3','login','95.92.119.110',NULL,'2026-09-04 16:10:28');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('3',NULL,'Email enviado para utilizador ID 92 | Template: utilizador_aprovado','95.92.119.110',NULL,'2026-09-04 16:10:50');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('4','92','login','41.205.52.232',NULL,'2026-09-04 16:17:59');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('5',NULL,'Email enviado para utilizador ID 93 | Template: utilizador_aprovado','95.92.119.110',NULL,'2026-09-04 17:06:50');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('6','93','login','95.92.119.110',NULL,'2026-09-04 17:07:28');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('7','93','logout','95.92.119.110',NULL,'2026-09-04 17:30:32');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('8','93','login','95.92.119.110',NULL,'2026-09-04 17:32:11');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('9','93','logout','95.92.119.110',NULL,'2026-09-04 20:00:12');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('10','93','login','95.92.119.110',NULL,'2026-09-04 20:00:38');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('11','93','login','10.255.129.19',NULL,'2026-09-04 20:22:59');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('12','92','logout','41.205.52.232',NULL,'2026-09-05 00:57:32');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('13','92','login','41.205.52.232',NULL,'2026-09-05 00:58:01');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('14','92','logout','41.205.52.232',NULL,'2026-09-05 01:14:39');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('15','92','login','41.205.52.232',NULL,'2026-09-05 01:14:52');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('16','3','logout','95.92.119.110',NULL,'2026-09-05 22:40:18');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('17','93','logout','95.92.119.110',NULL,'2026-09-05 22:42:29');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('18','3','login','95.92.119.110',NULL,'2026-09-06 00:52:57');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('19',NULL,'Email enviado para utilizador ID 94 | Template: utilizador_aprovado','95.92.119.110',NULL,'2026-09-06 00:53:45');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('20','92','login','41.205.52.232',NULL,'2026-09-06 10:57:53');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('21','3','login','95.92.119.110',NULL,'2026-09-06 13:05:04');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('22','93','login','95.92.119.110',NULL,'2026-09-06 13:35:40');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('23','3','logout','95.92.119.110',NULL,'2026-09-06 18:52:06');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('24','3','login','95.92.119.110',NULL,'2026-09-06 18:52:26');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('25','93','logout','95.92.119.110',NULL,'2026-09-06 19:44:38');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('26','93','login','95.92.119.110',NULL,'2026-09-07 12:18:10');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('27','3','logout','95.92.119.110',NULL,'2026-09-07 12:19:18');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('28','3','login','95.92.119.110',NULL,'2026-09-07 12:19:47');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('29','3','logout','95.92.119.110',NULL,'2026-09-07 20:45:02');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('30','3','login','95.92.119.110',NULL,'2026-09-07 20:49:17');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('31','3','logout','95.92.119.110',NULL,'2026-09-07 21:41:45');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('32','93','logout','95.92.119.110',NULL,'2026-09-07 21:41:55');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('33','94','login','129.122.191.121',NULL,'2026-09-08 00:40:34');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('34','3','login','95.92.119.110',NULL,'2026-09-08 00:50:40');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('35','94','login','129.122.191.121',NULL,'2026-09-08 00:56:03');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('36','3','logout','95.92.119.110',NULL,'2026-09-08 01:02:15');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('37','3','login','95.92.119.110',NULL,'2026-09-08 11:11:30');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('38','3','login','95.92.119.110',NULL,'2026-09-08 14:10:06');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('39','3','logout','95.92.119.110',NULL,'2026-09-08 14:11:37');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('40','93','login','95.92.119.110',NULL,'2026-09-08 19:58:05');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('41','3','Alterou permissões do perfil ID 9','95.92.119.110',NULL,'2026-09-08 20:17:36');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('42','3','Alterou permissões do perfil ID 3','95.92.119.110',NULL,'2026-09-08 20:19:21');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('43','93','logout','95.92.119.110',NULL,'2026-09-08 20:20:04');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('44','93','login','95.92.119.110',NULL,'2026-09-08 20:20:40');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('45','3','Alterou permissões do perfil ID 3','95.92.119.110',NULL,'2026-09-08 20:29:01');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('46','3','Alterou permissões do perfil ID 9','95.92.119.110',NULL,'2026-09-08 20:30:59');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('47','93','logout','95.92.119.110',NULL,'2026-09-08 20:33:14');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('48','93','login','95.92.119.110',NULL,'2026-09-08 20:39:19');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('49','3','logout','95.92.119.110',NULL,'2026-09-09 16:09:24');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('50','3','login','95.92.119.110',NULL,'2026-09-09 16:09:51');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('51','93','login','95.92.119.110',NULL,'2026-09-09 17:26:50');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('52','93','logout','95.92.119.110',NULL,'2026-09-09 17:29:16');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('53','93','login','95.92.119.110',NULL,'2026-09-09 17:29:44');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('54','93','logout','95.92.119.110',NULL,'2026-09-09 18:11:58');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('55','93','login','95.92.119.110',NULL,'2026-09-09 18:14:59');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('56','94','login','129.122.191.121',NULL,'2026-09-10 00:37:57');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('57','93','login','95.92.119.110',NULL,'2026-09-10 12:50:25');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('58','3','login','95.92.119.110',NULL,'2026-09-11 19:49:13');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('59','3','logout','95.92.119.110',NULL,'2026-09-11 19:49:33');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('60','93','login','95.92.119.110',NULL,'2026-09-11 19:49:55');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('61','93','logout','95.92.119.110',NULL,'2026-09-11 21:27:08');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('62','93','login','95.92.119.110',NULL,'2026-09-11 21:28:14');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('63','93','logout','95.92.119.110',NULL,'2026-09-11 21:34:44');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('64','3','login','95.92.119.110',NULL,'2026-09-11 21:35:04');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('65','3','login','95.92.119.110',NULL,'2026-09-14 11:49:46');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('66','93','login','95.92.119.110',NULL,'2026-09-14 14:03:08');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('67','93','logout','95.92.119.110',NULL,'2026-09-14 15:39:33');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('68',NULL,'Email enviado para utilizador ID 97 | Template: utilizador_aprovado','95.92.119.110',NULL,'2026-09-14 15:43:32');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('69','97','login','95.92.119.110',NULL,'2026-09-14 15:44:34');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('70','97','logout','95.92.119.110',NULL,'2026-09-14 18:42:35');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('71','93','login','95.92.119.110',NULL,'2026-09-14 18:43:08');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('72','3','logout','95.92.119.110',NULL,'2026-09-14 20:49:10');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('73','3','login','95.92.119.110',NULL,'2026-09-14 20:49:32');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('74','93','logout','95.92.119.110',NULL,'2026-09-14 20:49:55');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('75','93','login','95.92.119.110',NULL,'2026-09-14 20:50:19');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('76','3','logout','95.92.119.110',NULL,'2026-09-14 20:58:03');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('77','3','login','95.92.119.110',NULL,'2026-09-14 20:58:27');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('78','3','logout','95.92.119.110',NULL,'2026-09-15 13:34:48');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('79','93','logout','95.92.119.110',NULL,'2026-09-15 13:35:02');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('80','93','login','95.92.119.110',NULL,'2026-09-15 14:41:54');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('81','3','login','95.92.119.110',NULL,'2026-09-15 14:43:54');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('82','93','logout','95.92.119.110',NULL,'2026-09-15 16:35:19');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('83','97','login','95.92.119.110',NULL,'2026-09-15 16:36:08');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('84','97','logout','95.92.119.110',NULL,'2026-09-15 16:39:58');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('85',NULL,'Email enviado para utilizador ID 98 | Template: utilizador_aprovado','95.92.119.110',NULL,'2026-09-15 18:37:57');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('86',NULL,'Email enviado para utilizador ID 99 | Template: utilizador_aprovado','95.92.119.110',NULL,'2026-09-15 19:15:11');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('87','99','login','105.168.41.246',NULL,'2026-09-15 19:15:17');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('88','98','login','102.210.7.185',NULL,'2026-09-15 20:26:45');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('89',NULL,'Email enviado para utilizador ID 100 | Template: utilizador_aprovado','95.92.119.110',NULL,'2026-09-15 20:31:55');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('90','93','login','95.92.119.110',NULL,'2026-09-15 20:33:51');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('91','100','login','102.202.246.6',NULL,'2026-09-15 20:40:36');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('92','100','logout','102.202.246.6',NULL,'2026-09-15 20:47:36');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('93','3','logout','95.92.119.110',NULL,'2026-09-15 21:06:32');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('94','3','login','95.92.119.110',NULL,'2026-09-16 17:14:11');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('95',NULL,'Email enviado para utilizador ID 101 | Template: utilizador_aprovado','95.92.119.110',NULL,'2026-09-16 17:18:48');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('96','3','logout','95.92.119.110',NULL,'2026-09-16 17:19:32');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('97','93','login','95.92.119.110',NULL,'2026-09-16 17:19:51');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('98','3','login','95.92.119.110',NULL,'2026-09-16 17:21:26');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('99','3','login','95.92.119.110',NULL,'2026-09-16 19:32:58');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('100','93','login','95.92.119.110',NULL,'2026-09-16 20:07:49');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('101','3','login','95.92.119.110',NULL,'2026-09-16 20:28:23');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('102','3','logout','95.92.119.110',NULL,'2026-09-16 20:31:36');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('103','93','logout','95.92.119.110',NULL,'2026-09-17 13:21:52');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('104','93','login','95.92.119.110',NULL,'2026-09-17 13:22:13');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('105','93','logout','95.92.119.110',NULL,'2026-09-17 18:57:04');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('106','3','logout','95.92.119.110',NULL,'2026-09-17 18:57:23');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('107','3','login','95.92.119.110',NULL,'2026-09-17 18:57:53');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('108','93','login','95.92.119.110',NULL,'2026-09-17 19:53:21');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('109',NULL,'Email enviado para utilizador ID 95 | Template: utilizador_aprovado','95.92.119.110',NULL,'2026-09-17 20:05:59');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('110','93','login','95.92.119.110',NULL,'2026-09-18 17:09:38');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('111','3','login','95.92.119.110',NULL,'2026-09-18 17:10:34');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('112','93','logout','95.92.119.110',NULL,'2026-09-18 18:30:54');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('113','93','login','95.92.119.110',NULL,'2026-09-18 19:15:04');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('114','93','login','95.92.119.110',NULL,'2026-09-20 12:41:51');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('115','3','login','95.92.119.110',NULL,'2026-09-20 12:46:57');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('116','3','logout','95.92.119.110',NULL,'2026-09-20 13:06:55');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('117','3','login','95.92.119.110',NULL,'2026-09-20 13:16:15');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('118','3','logout','95.92.119.110',NULL,'2026-09-20 20:11:53');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('119','93','logout','95.92.119.110',NULL,'2026-09-20 20:12:02');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('120','93','login','95.92.119.110',NULL,'2026-09-22 16:25:51');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('121','3','login','95.92.119.110',NULL,'2026-09-22 16:27:45');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('122','93','logout','95.92.119.110',NULL,'2026-09-22 17:25:51');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('123','93','login','95.92.119.110',NULL,'2026-09-22 17:26:34');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('124','3','logout','95.92.119.110',NULL,'2026-09-22 17:49:27');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('125','93','logout','95.92.119.110',NULL,'2026-09-22 17:49:43');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('126','93','login','95.92.119.110',NULL,'2026-09-22 19:11:46');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('127','3','login','95.92.119.110',NULL,'2026-09-22 19:13:05');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('128','3','login','95.92.119.110',NULL,'2026-09-22 19:36:31');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('129','3','logout','95.92.119.110',NULL,'2026-09-22 19:39:01');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('130','93','logout','95.92.119.110',NULL,'2026-09-22 21:03:48');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('131','93','login','95.92.119.110',NULL,'2026-09-22 21:04:22');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('132','93','logout','95.92.119.110',NULL,'2026-09-22 21:58:07');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('133','3','login','95.92.119.110',NULL,'2026-09-23 11:50:34');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('134','3','logout','95.92.119.110',NULL,'2026-09-23 12:12:16');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('135','3','login','95.92.119.110',NULL,'2026-09-23 12:12:39');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('136','3','logout','95.92.119.110',NULL,'2026-09-23 12:43:21');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('137','3','login','95.92.119.110',NULL,'2026-09-23 12:43:40');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('138','3','logout','95.92.119.110',NULL,'2026-09-23 12:54:39');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('139','3','login','95.92.119.110',NULL,'2026-09-23 12:54:58');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('140','3','logout','95.92.119.110',NULL,'2026-09-23 13:04:25');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('141','3','login','95.92.119.110',NULL,'2026-09-23 13:04:45');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('142','93','login','95.92.119.110',NULL,'2026-09-23 13:06:22');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('143','3','logout','95.92.119.110',NULL,'2026-09-23 13:23:18');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('144','3','login','95.92.119.110',NULL,'2026-09-23 13:23:35');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('145','3','logout','95.92.119.110',NULL,'2026-09-23 13:52:08');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('146','3','login','95.92.119.110',NULL,'2026-09-23 13:52:29');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('147','3','logout','95.92.119.110',NULL,'2026-09-23 14:11:12');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('148','93','login','95.92.119.110',NULL,'2026-09-23 14:11:34');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('149','93','logout','95.92.119.110',NULL,'2026-09-23 14:11:41');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('150','3','login','95.92.119.110',NULL,'2026-09-23 14:12:00');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('151','3','logout','95.92.119.110',NULL,'2026-09-23 14:17:20');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('152','3','login','95.92.119.110',NULL,'2026-09-23 14:17:39');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('153','93','logout','95.92.119.110',NULL,'2026-09-23 14:42:58');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('154','93','login','95.92.119.110',NULL,'2026-09-23 14:43:21');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('155','3','logout','95.92.119.110',NULL,'2026-09-23 17:47:04');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('156','3','login','95.92.119.110',NULL,'2026-09-23 17:48:29');


-- Estrutura da tabela `auditoria_eliminacoes`
CREATE TABLE `auditoria_eliminacoes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tabela` varchar(100) NOT NULL,
  `acao` varchar(50) DEFAULT NULL,
  `registo_id` int NOT NULL,
  `dados` json NOT NULL,
  `apagado_por` int DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dados da tabela `auditoria_eliminacoes`
INSERT INTO `auditoria_eliminacoes` (`id`,`tabela`,`acao`,`registo_id`,`dados`,`apagado_por`,`ip`,`criado_em`) VALUES ('1','utilizadores',NULL,'91','{\"id\": 91, \"nome\": \"António Almeida\", \"ativo\": 1, \"email\": \"antonio.almeida@anferalta.com\", \"password\": \"$2y$12$LotyBUyH5mmIVB6RgDre/O9f9GSHmHYZ3KeTPmO15Dg3MdWM9yhui\", \"criado_em\": \"2026-08-21 18:32:31\", \"perfil_id\": 9, \"aprovado_em\": \"2026-08-21 18:43:39\", \"aprovado_por\": 3, \"ultimo_login\": null, \"tentativas_falhadas\": 0}','3','95.92.119.110','2026-09-03 12:48:10');
INSERT INTO `auditoria_eliminacoes` (`id`,`tabela`,`acao`,`registo_id`,`dados`,`apagado_por`,`ip`,`criado_em`) VALUES ('2','utilizadores',NULL,'90','{\"id\": 90, \"nome\": \"Daniel Almeida\", \"ativo\": 1, \"email\": \"daniel.almeida@anferalta.com\", \"password\": \"$2y$12$nmB7euHRgNnUiZpLXht9geq39fUvEHiPfaPf7ToMYx3M1BQ1tLSZ6\", \"criado_em\": \"2026-08-20 11:50:03\", \"perfil_id\": 3, \"aprovado_em\": \"2026-08-20 11:59:47\", \"aprovado_por\": 3, \"ultimo_login\": null, \"tentativas_falhadas\": 0}','3','95.92.119.110','2026-09-03 12:48:20');
INSERT INTO `auditoria_eliminacoes` (`id`,`tabela`,`acao`,`registo_id`,`dados`,`apagado_por`,`ip`,`criado_em`) VALUES ('3','utilizadores',NULL,'88','{\"id\": 88, \"nome\": \"Gisela Freitas\", \"ativo\": 0, \"email\": \"gisela.freitas@anferalta.com\", \"password\": \"$2y$12$0r3jvOchHIw17c/zidQUFukcL.pS2r5vq9qCYXJhfYnGPI6.IDM7u\", \"criado_em\": \"2026-07-23 21:15:44\", \"perfil_id\": 1, \"aprovado_em\": null, \"aprovado_por\": null, \"ultimo_login\": null, \"tentativas_falhadas\": 0}','3','95.92.119.110','2026-09-03 12:48:33');
INSERT INTO `auditoria_eliminacoes` (`id`,`tabela`,`acao`,`registo_id`,`dados`,`apagado_por`,`ip`,`criado_em`) VALUES ('4','utilizadores',NULL,'87','{\"id\": 87, \"nome\": \"Gisela Freitas\", \"ativo\": 1, \"email\": \"gisela.freita@anferalta.com\", \"password\": \"$2y$12$pIly1.7oK0STG5jt.e.2OeOZPcz5ZZ.HEIQg0HpcBNilZIfF3dxGe\", \"criado_em\": \"2026-07-13 21:22:36\", \"perfil_id\": 4, \"aprovado_em\": \"2026-07-13 21:25:01\", \"aprovado_por\": 3, \"ultimo_login\": null, \"tentativas_falhadas\": 0}','3','95.92.119.110','2026-09-03 12:48:40');
INSERT INTO `auditoria_eliminacoes` (`id`,`tabela`,`acao`,`registo_id`,`dados`,`apagado_por`,`ip`,`criado_em`) VALUES ('5','utilizadores',NULL,'4','{\"id\": 4, \"nome\": \"Antonio\", \"ativo\": 0, \"email\": \"anferalta@gmail.com\", \"password\": \"$2y$12$9GNk59my7060OVJX4Q7DTOPW5TR1UW0VQ06DBhx96r0y1cRRPYKfu\", \"criado_em\": \"2026-02-15 19:44:41\", \"perfil_id\": 1, \"aprovado_em\": \"2026-04-07 17:11:08\", \"aprovado_por\": null, \"ultimo_login\": null, \"tentativas_falhadas\": 0}','3','95.92.119.110','2026-09-03 12:48:55');
INSERT INTO `auditoria_eliminacoes` (`id`,`tabela`,`acao`,`registo_id`,`dados`,`apagado_por`,`ip`,`criado_em`) VALUES ('6','documentos',NULL,'13','{\"id\": 13, \"hash\": null, \"estado\": 1, \"titulo\": \"Continuação do teste preview que não funciona.\", \"caminho\": null, \"tamanho\": null, \"tipo_id\": 4, \"ficheiro\": null, \"criado_em\": \"2026-09-18 17:53:05\", \"mime_type\": null, \"criado_por\": 93, \"arquivado_em\": null, \"estado_atual\": \"novo\", \"area_atual_id\": null, \"area_atual_desde\": \"2026-09-18 17:53:05\", \"arquivado_por_id\": null, \"ficheiro_original\": null}','3','95.92.119.110','2026-09-20 12:47:41');
INSERT INTO `auditoria_eliminacoes` (`id`,`tabela`,`acao`,`registo_id`,`dados`,`apagado_por`,`ip`,`criado_em`) VALUES ('7','documentos',NULL,'9','{\"id\": 9, \"hash\": null, \"estado\": 1, \"titulo\": \"Teste\", \"caminho\": null, \"tamanho\": null, \"tipo_id\": 3, \"ficheiro\": null, \"criado_em\": \"2026-09-10 13:18:39\", \"mime_type\": null, \"criado_por\": 93, \"arquivado_em\": null, \"estado_atual\": \"devolvido\", \"area_atual_id\": 1, \"area_atual_desde\": \"2026-09-14 14:07:44\", \"arquivado_por_id\": null, \"ficheiro_original\": null}','3','95.92.119.110','2026-09-20 12:48:44');
INSERT INTO `auditoria_eliminacoes` (`id`,`tabela`,`acao`,`registo_id`,`dados`,`apagado_por`,`ip`,`criado_em`) VALUES ('8','documentos',NULL,'12','{\"id\": 12, \"hash\": null, \"estado\": 1, \"titulo\": \"Preview não funciona\", \"caminho\": null, \"tamanho\": null, \"tipo_id\": 29, \"ficheiro\": null, \"criado_em\": \"2026-09-16 18:24:10\", \"mime_type\": null, \"criado_por\": 93, \"arquivado_em\": null, \"estado_atual\": \"novo\", \"area_atual_id\": null, \"area_atual_desde\": \"2026-09-16 18:24:10\", \"arquivado_por_id\": null, \"ficheiro_original\": null}','3','95.92.119.110','2026-09-20 12:48:53');
INSERT INTO `auditoria_eliminacoes` (`id`,`tabela`,`acao`,`registo_id`,`dados`,`apagado_por`,`ip`,`criado_em`) VALUES ('9','documentos',NULL,'2','{\"id\": 2, \"hash\": null, \"estado\": 1, \"titulo\": \"Novo teste da BD\", \"caminho\": null, \"tamanho\": null, \"tipo_id\": 29, \"ficheiro\": null, \"criado_em\": \"2026-09-05 00:46:57\", \"mime_type\": null, \"criado_por\": 93, \"arquivado_em\": null, \"estado_atual\": \"pendente\", \"area_atual_id\": 1, \"area_atual_desde\": \"2026-09-07 12:26:33\", \"arquivado_por_id\": null, \"ficheiro_original\": null}','3','95.92.119.110','2026-09-20 12:49:42');
INSERT INTO `auditoria_eliminacoes` (`id`,`tabela`,`acao`,`registo_id`,`dados`,`apagado_por`,`ip`,`criado_em`) VALUES ('10','documentos',NULL,'11','{\"id\": 11, \"hash\": null, \"estado\": 1, \"titulo\": \"Teste de documentos docx\", \"caminho\": null, \"tamanho\": null, \"tipo_id\": 6, \"ficheiro\": null, \"criado_em\": \"2026-09-14 18:45:26\", \"mime_type\": null, \"criado_por\": 93, \"arquivado_em\": null, \"estado_atual\": \"pendente\", \"area_atual_id\": 2, \"area_atual_desde\": \"2026-09-15 13:00:01\", \"arquivado_por_id\": null, \"ficheiro_original\": null}','3','95.92.119.110','2026-09-20 12:50:38');
INSERT INTO `auditoria_eliminacoes` (`id`,`tabela`,`acao`,`registo_id`,`dados`,`apagado_por`,`ip`,`criado_em`) VALUES ('11','documentos',NULL,'8','{\"id\": 8, \"hash\": null, \"estado\": 1, \"titulo\": \"Verificar fluxo de tramitação\", \"caminho\": null, \"tamanho\": null, \"tipo_id\": 29, \"ficheiro\": null, \"criado_em\": \"2026-09-09 17:33:06\", \"mime_type\": null, \"criado_por\": 93, \"arquivado_em\": null, \"estado_atual\": \"novo\", \"area_atual_id\": 1, \"area_atual_desde\": \"2026-09-14 11:55:15\", \"arquivado_por_id\": null, \"ficheiro_original\": null}','3','95.92.119.110','2026-09-20 12:56:13');
INSERT INTO `auditoria_eliminacoes` (`id`,`tabela`,`acao`,`registo_id`,`dados`,`apagado_por`,`ip`,`criado_em`) VALUES ('12','documentos',NULL,'6','{\"id\": 6, \"hash\": null, \"estado\": 1, \"titulo\": \"Teste do CSRF\", \"caminho\": null, \"tamanho\": null, \"tipo_id\": 4, \"ficheiro\": null, \"criado_em\": \"2026-09-07 12:55:23\", \"mime_type\": null, \"criado_por\": 93, \"arquivado_em\": null, \"estado_atual\": \"novo\", \"area_atual_id\": 8, \"area_atual_desde\": \"2026-09-07 20:55:45\", \"arquivado_por_id\": null, \"ficheiro_original\": null}','3','95.92.119.110','2026-09-20 12:58:44');
INSERT INTO `auditoria_eliminacoes` (`id`,`tabela`,`acao`,`registo_id`,`dados`,`apagado_por`,`ip`,`criado_em`) VALUES ('13','documentos',NULL,'14','{\"id\": 14, \"hash\": null, \"estado\": 1, \"titulo\": \"Teste preview.\", \"caminho\": null, \"tamanho\": null, \"tipo_id\": 4, \"ficheiro\": null, \"criado_em\": \"2026-09-22 20:19:04\", \"mime_type\": null, \"criado_por\": 93, \"arquivado_em\": null, \"estado_atual\": \"em_tramitacao\", \"area_atual_id\": 8, \"area_atual_desde\": \"2026-09-23 13:26:10\", \"arquivado_por_id\": null, \"ficheiro_original\": null}','3','95.92.119.110','2026-09-23 14:41:18');
INSERT INTO `auditoria_eliminacoes` (`id`,`tabela`,`acao`,`registo_id`,`dados`,`apagado_por`,`ip`,`criado_em`) VALUES ('14','documentos',NULL,'15','{\"id\": 15, \"hash\": null, \"estado\": 1, \"titulo\": \"Teste 2\", \"caminho\": null, \"tamanho\": null, \"tipo_id\": 3, \"ficheiro\": null, \"criado_em\": \"2026-09-22 20:22:06\", \"mime_type\": null, \"criado_por\": 93, \"arquivado_em\": null, \"estado_atual\": \"novo\", \"area_atual_id\": null, \"area_atual_desde\": \"2026-09-22 20:22:06\", \"arquivado_por_id\": null, \"ficheiro_original\": null}','3','95.92.119.110','2026-09-23 14:41:27');


-- Estrutura da tabela `documento_areas`
CREATE TABLE `documento_areas` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `codigo` varchar(50) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  `criado_em` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `atualizado_em` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `prazo_resposta` int DEFAULT '3',
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dados da tabela `documento_areas`
INSERT INTO `documento_areas` (`id`,`nome`,`codigo`,`descricao`,`ativo`,`criado_em`,`atualizado_em`,`prazo_resposta`) VALUES ('1','Secretaria','SEC','Receção e distribuição de documentos','1','2026-04-18 21:00:15','2026-06-04 22:08:35','1');
INSERT INTO `documento_areas` (`id`,`nome`,`codigo`,`descricao`,`ativo`,`criado_em`,`atualizado_em`,`prazo_resposta`) VALUES ('2','Direção','DIR','Direção geral','1','2026-04-18 21:00:15','2026-06-06 13:34:26','5');
INSERT INTO `documento_areas` (`id`,`nome`,`codigo`,`descricao`,`ativo`,`criado_em`,`atualizado_em`,`prazo_resposta`) VALUES ('3','Financeira','FIN','Departamento financeiro','1','2026-04-18 21:00:15','2026-06-04 22:08:11','2');
INSERT INTO `documento_areas` (`id`,`nome`,`codigo`,`descricao`,`ativo`,`criado_em`,`atualizado_em`,`prazo_resposta`) VALUES ('4','Recursos Humanos','RH','Gestão de pessoal','1','2026-04-18 21:00:15','2026-06-04 22:09:18','2');
INSERT INTO `documento_areas` (`id`,`nome`,`codigo`,`descricao`,`ativo`,`criado_em`,`atualizado_em`,`prazo_resposta`) VALUES ('5','Arquivo','ARQ','Arquivo e documentação','1','2026-04-18 21:00:15','2026-07-22 19:55:44','3');
INSERT INTO `documento_areas` (`id`,`nome`,`codigo`,`descricao`,`ativo`,`criado_em`,`atualizado_em`,`prazo_resposta`) VALUES ('8','Gabinete Jurídico ','JUR','Gabinete jurídico ','1','2026-05-23 14:17:30','2026-06-04 22:09:45','2');


-- Estrutura da tabela `documento_estados`
CREATE TABLE `documento_estados` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordem` int unsigned NOT NULL DEFAULT '1',
  `final` tinyint(1) NOT NULL DEFAULT '0',
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_codigo` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dados da tabela `documento_estados`
INSERT INTO `documento_estados` (`id`,`codigo`,`nome`,`ordem`,`final`,`ativo`) VALUES ('1','pendente','Pendente','1','0','1');
INSERT INTO `documento_estados` (`id`,`codigo`,`nome`,`ordem`,`final`,`ativo`) VALUES ('2','em_tramitacao','Em Tramitação','2','0','1');
INSERT INTO `documento_estados` (`id`,`codigo`,`nome`,`ordem`,`final`,`ativo`) VALUES ('3','analise','Em Análise','3','0','1');
INSERT INTO `documento_estados` (`id`,`codigo`,`nome`,`ordem`,`final`,`ativo`) VALUES ('4','concluido','Concluído','4','0','1');
INSERT INTO `documento_estados` (`id`,`codigo`,`nome`,`ordem`,`final`,`ativo`) VALUES ('5','devolvido','Devolvido','5','0','1');
INSERT INTO `documento_estados` (`id`,`codigo`,`nome`,`ordem`,`final`,`ativo`) VALUES ('6','arquivado','Arquivado','6','1','1');
INSERT INTO `documento_estados` (`id`,`codigo`,`nome`,`ordem`,`final`,`ativo`) VALUES ('13','novo','Novo','0','0','1');


-- Estrutura da tabela `documento_ficheiros`
CREATE TABLE `documento_ficheiros` (
  `id` int NOT NULL AUTO_INCREMENT,
  `documento_id` int NOT NULL,
  `ficheiro` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ficheiro_original` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `caminho` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tamanho` int DEFAULT NULL,
  `mime` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `documento_id` (`documento_id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dados da tabela `documento_ficheiros`
INSERT INTO `documento_ficheiros` (`id`,`documento_id`,`ficheiro`,`ficheiro_original`,`caminho`,`tamanho`,`mime`,`criado_em`) VALUES ('1','1','6a9b4a0613617_relatorio_sla.pdf','relatorio_sla.pdf','2026/09/05/','21848','application/pdf','2026-09-05 00:45:26');
INSERT INTO `documento_ficheiros` (`id`,`documento_id`,`ficheiro`,`ficheiro_original`,`caminho`,`tamanho`,`mime`,`criado_em`) VALUES ('2','2','6a9b4a618fced_contrato_de_arrendamento_de_c__mera_frigor__fica.pdf','contrato de arrendamento de câmera frigorífica.pdf','2026/09/05/','2818530','application/pdf','2026-09-05 00:46:57');
INSERT INTO `documento_ficheiros` (`id`,`documento_id`,`ficheiro`,`ficheiro_original`,`caminho`,`tamanho`,`mime`,`criado_em`) VALUES ('3','3','6a9b4bf856c98_8ca1da5d08918a6cb4cefc8f4b7be2f4.png','8ca1da5d08918a6cb4cefc8f4b7be2f4.png','2026/09/05/','1277565','image/png','2026-09-05 00:53:44');
INSERT INTO `documento_ficheiros` (`id`,`documento_id`,`ficheiro`,`ficheiro_original`,`caminho`,`tamanho`,`mime`,`criado_em`) VALUES ('4','4','6a9b4e61988b0_Os_segredos_que_vA____o_mudar_sua_vida.pdf','Os segredos que vÃ£o mudar sua vida.pdf','2026/09/05/','1915495','application/pdf','2026-09-05 01:04:01');
INSERT INTO `documento_ficheiros` (`id`,`documento_id`,`ficheiro`,`ficheiro_original`,`caminho`,`tamanho`,`mime`,`criado_em`) VALUES ('5','5','6a9b4fa923009_SEBRAE_-_Planilhas_de_Apoio_a___Gesta__o_Empresarial.xlsx','SEBRAE - Planilhas de Apoio à Gestão Empresarial.xlsx','2026/09/05/','30461','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','2026-09-05 01:09:29');
INSERT INTO `documento_ficheiros` (`id`,`documento_id`,`ficheiro`,`ficheiro_original`,`caminho`,`tamanho`,`mime`,`criado_em`) VALUES ('6','6','6a9e981b34e29_declara____o_anual_de_rendimento_2020.pdf','declaração anual de rendimento 2020.pdf','2026/09/07/','4664467','application/pdf','2026-09-07 12:55:23');
INSERT INTO `documento_ficheiros` (`id`,`documento_id`,`ficheiro`,`ficheiro_original`,`caminho`,`tamanho`,`mime`,`criado_em`) VALUES ('7','6','6a9e981b36fa4_pretty.jpeg','pretty.jpeg','2026/09/07/','152427','image/jpeg','2026-09-07 12:55:23');
INSERT INTO `documento_ficheiros` (`id`,`documento_id`,`ficheiro`,`ficheiro_original`,`caminho`,`tamanho`,`mime`,`criado_em`) VALUES ('8','6','6a9e981b37560_teste_teams.docx','teste teams.docx','2026/09/07/','29051','application/vnd.openxmlformats-officedocument.wordprocessingml.document','2026-09-07 12:55:23');
INSERT INTO `documento_ficheiros` (`id`,`documento_id`,`ficheiro`,`ficheiro_original`,`caminho`,`tamanho`,`mime`,`criado_em`) VALUES ('9','6','6a9e981b39a3e_factura.jpg','factura.jpg','2026/09/07/','460917','image/jpeg','2026-09-07 12:55:23');
INSERT INTO `documento_ficheiros` (`id`,`documento_id`,`ficheiro`,`ficheiro_original`,`caminho`,`tamanho`,`mime`,`criado_em`) VALUES ('10','7','6a9f3e7027aa8_Despedida.pdf','Despedida.pdf','2026/09/08/','72826','application/pdf','2026-09-08 00:45:04');
INSERT INTO `documento_ficheiros` (`id`,`documento_id`,`ficheiro`,`ficheiro_original`,`caminho`,`tamanho`,`mime`,`criado_em`) VALUES ('11','8','6aa17c3213da2_Sem_t__tulo.txt','Sem título.txt','2026/09/09/','4635','text/plain','2026-09-09 17:33:06');
INSERT INTO `documento_ficheiros` (`id`,`documento_id`,`ficheiro`,`ficheiro_original`,`caminho`,`tamanho`,`mime`,`criado_em`) VALUES ('12','8','6aa17c3219a29_minuta-declaracao-de-alojamento.pdf','minuta-declaracao-de-alojamento.pdf','2026/09/09/','390147','application/pdf','2026-09-09 17:33:06');
INSERT INTO `documento_ficheiros` (`id`,`documento_id`,`ficheiro`,`ficheiro_original`,`caminho`,`tamanho`,`mime`,`criado_em`) VALUES ('13','8','6aa17c321a2d3_03_Decl_Compromisso_Atividade.docx','03_Decl_Compromisso_Atividade.docx','2026/09/09/','27434','application/vnd.openxmlformats-officedocument.wordprocessingml.document','2026-09-09 17:33:06');
INSERT INTO `documento_ficheiros` (`id`,`documento_id`,`ficheiro`,`ficheiro_original`,`caminho`,`tamanho`,`mime`,`criado_em`) VALUES ('14','8','6aa17c321a9e7_emanuele_caetano.jpg','emanuele caetano.jpg','2026/09/09/','100089','image/jpeg','2026-09-09 17:33:06');
INSERT INTO `documento_ficheiros` (`id`,`documento_id`,`ficheiro`,`ficheiro_original`,`caminho`,`tamanho`,`mime`,`criado_em`) VALUES ('15','9','6aa2920f108ff_factura_RAMBAS_LDA.docx','factura RAMBAS LDA.docx','2026/09/10/','14013','application/vnd.openxmlformats-officedocument.wordprocessingml.document','2026-09-10 13:18:39');
INSERT INTO `documento_ficheiros` (`id`,`documento_id`,`ficheiro`,`ficheiro_original`,`caminho`,`tamanho`,`mime`,`criado_em`) VALUES ('16','10','6aa7e321eadc4_proposta_de_compra_de_carro_el__ctrico_Fiat_.pdf','proposta de compra de carro eléctrico(Fiat).pdf','2026/09/14/','150663','application/pdf','2026-09-14 14:05:53');
INSERT INTO `documento_ficheiros` (`id`,`documento_id`,`ficheiro`,`ficheiro_original`,`caminho`,`tamanho`,`mime`,`criado_em`) VALUES ('17','11','6aa824a6c3af3_solicita____o_de_declara____o_de_vencimento_.docx','solicitação de declaração de vencimento .docx','2026/09/14/','14555','application/vnd.openxmlformats-officedocument.wordprocessingml.document','2026-09-14 18:45:26');
INSERT INTO `documento_ficheiros` (`id`,`documento_id`,`ficheiro`,`ficheiro_original`,`caminho`,`tamanho`,`mime`,`criado_em`) VALUES ('18','11','6aa824a6c64cc_pedido_de_autoriza____o_de_saida.docx','pedido de autorização de saida.docx','2026/09/14/','17039','application/vnd.openxmlformats-officedocument.wordprocessingml.document','2026-09-14 18:45:26');
INSERT INTO `documento_ficheiros` (`id`,`documento_id`,`ficheiro`,`ficheiro_original`,`caminho`,`tamanho`,`mime`,`criado_em`) VALUES ('19','12','6aaac2aa8f8b6_Actualiza____o_de_cadastro.docx','Actualização de cadastro.docx','2026/09/16/','27690','application/vnd.openxmlformats-officedocument.wordprocessingml.document','2026-09-16 18:24:10');
INSERT INTO `documento_ficheiros` (`id`,`documento_id`,`ficheiro`,`ficheiro_original`,`caminho`,`tamanho`,`mime`,`criado_em`) VALUES ('20','13','6aad5e6134ea9_Contrato_de_trabalho_lisboa.pdf','Contrato de trabalho lisboa.pdf','2026/09/18/','1019054','application/pdf','2026-09-18 17:53:05');
INSERT INTO `documento_ficheiros` (`id`,`documento_id`,`ficheiro`,`ficheiro_original`,`caminho`,`tamanho`,`mime`,`criado_em`) VALUES ('21','14','6ab2c698e4813_18.docx','18.docx','2026/09/22/','17039','application/vnd.openxmlformats-officedocument.wordprocessingml.document','2026-09-22 20:19:04');
INSERT INTO `documento_ficheiros` (`id`,`documento_id`,`ficheiro`,`ficheiro_original`,`caminho`,`tamanho`,`mime`,`criado_em`) VALUES ('22','15','6ab2c74e51190_5612600_comprovativo.pdf','5612600_comprovativo.pdf','2026/09/22/','23910','application/pdf','2026-09-22 20:22:06');


-- Estrutura da tabela `documento_tipos`
CREATE TABLE `documento_tipos` (
  `tipo_id` int unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  PRIMARY KEY (`tipo_id`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dados da tabela `documento_tipos`
INSERT INTO `documento_tipos` (`tipo_id`,`nome`) VALUES ('1','Carta');
INSERT INTO `documento_tipos` (`tipo_id`,`nome`) VALUES ('2','Ofício');
INSERT INTO `documento_tipos` (`tipo_id`,`nome`) VALUES ('3','Pedido');
INSERT INTO `documento_tipos` (`tipo_id`,`nome`) VALUES ('4','Relatório');
INSERT INTO `documento_tipos` (`tipo_id`,`nome`) VALUES ('5','Memorando');
INSERT INTO `documento_tipos` (`tipo_id`,`nome`) VALUES ('6','Circular');
INSERT INTO `documento_tipos` (`tipo_id`,`nome`) VALUES ('29','Exposiçao');
INSERT INTO `documento_tipos` (`tipo_id`,`nome`) VALUES ('35','Finanças');


-- Estrutura da tabela `documento_tramitacao`
CREATE TABLE `documento_tramitacao` (
  `id` int NOT NULL AUTO_INCREMENT,
  `documento_id` int NOT NULL,
  `utilizador_id` int NOT NULL,
  `acao` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `area_id` int DEFAULT NULL,
  `comentario` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `estado` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `criado_em` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `documento_id` (`documento_id`),
  KEY `utilizador_id` (`utilizador_id`),
  KEY `area_id` (`area_id`),
  KEY `estado` (`estado`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dados da tabela `documento_tramitacao`
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('1','3','3','COMENTARIO',NULL,'Teste','novo','2026-09-05 01:04:47');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('2','3','3','ENCAMINHADO','1','ver documentos','em_tramitacao','2026-09-05 01:05:17');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('3','3','3','ESTADO','1','Verificar documentação','analise','2026-09-05 01:05:47');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('4','4','3','COMENTARIO',NULL,'Muito urgente','novo','2026-09-05 01:07:23');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('5','4','3','ENCAMINHADO','3','Verificar pagamento','em_tramitacao','2026-09-05 01:07:53');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('6','4','3','ESTADO','3','Verificar pagamento','em_tramitacao','2026-09-05 01:08:17');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('7','4','92','ENCAMINHADO','2',NULL,'em_tramitacao','2026-09-05 01:21:26');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('8','5','92','ESTADO',NULL,NULL,'em_tramitacao','2026-09-06 11:03:58');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('9','1','3','COMENTARIO',NULL,'Teste da BD, em produção.','novo','2026-09-06 13:06:43');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('10','1','3','ENCAMINHADO','4','Testar BD em produção.','em_tramitacao','2026-09-06 13:07:24');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('11','1','3','ESTADO','4','Testar BD em produção.','em_tramitacao','2026-09-06 13:07:55');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('12','2','3','COMENTARIO',NULL,'Teste do fluxo de tramitação.','novo','2026-09-06 13:08:52');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('13','2','3','ENCAMINHADO','8','Verificar tramitação.','em_tramitacao','2026-09-06 13:09:16');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('14','2','3','ESTADO','8','Verificar fluxo de tramitação.','analise','2026-09-06 13:09:50');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('15','5','3','COMENTARIO',NULL,'Correcção de erros no fluxo de tramitação.','em_tramitacao','2026-09-06 13:11:03');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('16','5','3','ENCAMINHADO','8','Corrigir erros no fluxo de tramitação.','em_tramitacao','2026-09-06 13:11:43');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('17','5','3','ESTADO','8','correcção do fluxo de tramitação.','concluido','2026-09-06 13:12:25');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('18','1','3','COMENTARIO','4','Teste concluído.','em_tramitacao','2026-09-07 12:23:50');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('19','1','3','ESTADO','4','teste concluido.','concluido','2026-09-07 12:24:16');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('20','1','3','ESTADO','4','Documento arquivado.','arquivado','2026-09-07 12:24:22');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('21','2','3','COMENTARIO','8','Falta ajustar CSRF.','analise','2026-09-07 12:26:08');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('22','2','3','ENCAMINHADO','1','Falta ajustar CSRF.','em_tramitacao','2026-09-07 12:26:33');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('23','2','3','ESTADO','1','Falta ajustar CSRF.','pendente','2026-09-07 12:26:45');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('24','6','3','COMENTARIO',NULL,'Testar CSRF.','novo','2026-09-07 12:58:51');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('25','3','3','COMENTARIO','1','Aprovar documento.','analise','2026-09-07 20:34:10');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('26','6','3','ENCAMINHADO','8','Teste ao fluxo.','em_tramitacao','2026-09-07 20:55:45');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('27','6','3','ESTADO','8','Teste ao fluxo.','devolvido','2026-09-07 20:56:26');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('28','1','3','RECUPERAR','4','Documento recuperado do arquivo para produção.','recuperado','2026-09-07 21:05:26');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('29','1','3','COMENTARIO','4','Reavaliar processo','novo','2026-09-07 21:06:00');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('30','1','3','ESTADO','4',NULL,'teste','2026-09-07 21:29:27');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('31','1','3','COMENTARIO','4','Testar estados','teste','2026-09-07 21:31:58');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('32','1','3','ESTADO','4','Testar estados.','concluido','2026-09-07 21:32:32');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('33','7','3','ENCAMINHADO','8','Para parecer.','em_tramitacao','2026-09-08 00:51:52');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('34','7','3','ESTADO','8','Para parecer.','analise','2026-09-08 00:52:11');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('35','6','3','ESTADO','8',NULL,'concluido','2026-09-09 16:56:31');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('36','6','3','ESTADO','8','Documento arquivado.','arquivado','2026-09-09 16:56:37');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('37','7','3','COMENTARIO','8','Arquivar.','analise','2026-09-09 17:10:32');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('38','8','3','COMENTARIO',NULL,'Teste de funcionamento do sistema.','novo','2026-09-14 11:54:36');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('39','8','3','ENCAMINHADO','1','Teste de funcionamento do sistema.','em_tramitacao','2026-09-14 11:55:15');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('40','8','3','ESTADO','1','Teste de funcionamento.','em_tramitacao','2026-09-14 11:55:57');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('41','9','3','COMENTARIO',NULL,'Arquivar','novo','2026-09-14 14:07:18');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('42','9','3','ENCAMINHADO','1','Informar utente.','em_tramitacao','2026-09-14 14:07:44');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('43','9','3','ESTADO','1','não reúne requisitos.','devolvido','2026-09-14 14:08:13');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('44','10','97','COMENTARIO',NULL,'Teste de fiabilidade','novo','2026-09-14 15:56:18');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('45','11','3','COMENTARIO',NULL,'Testar Preview.','novo','2026-09-15 12:59:26');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('46','11','3','ENCAMINHADO','2','Testar Preview.','em_tramitacao','2026-09-15 13:00:01');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('47','11','3','ESTADO','2','Testar Preview.','pendente','2026-09-15 13:00:42');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('48','10','3','COMENTARIO',NULL,'Testar fiabilidade do sistema.','novo','2026-09-15 14:47:27');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('49','10','3','ENCAMINHADO','2','Teste Preview.','em_tramitacao','2026-09-16 20:46:26');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('50','8','3','COMENTARIO','1','Arquivar.','em_tramitacao','2026-09-17 19:01:21');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('51','8','3','ESTADO','1','Documento arquivado.','arquivado','2026-09-17 19:01:28');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('52','12','3','COMENTARIO',NULL,'Preview não funciona.','novo','2026-09-17 19:03:07');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('53','8','3','RECUPERAR','1','Documento recuperado do arquivo para produção.','recuperado','2026-09-20 12:56:01');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('54','6','3','RECUPERAR','8','Documento recuperado do arquivo para produção.','recuperado','2026-09-20 12:58:33');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('55','1','3','COMENTARIO','4','Arquivar.','concluido','2026-09-20 13:26:19');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('56','1','3','ESTADO','4','Documento arquivado.','arquivado','2026-09-20 13:26:27');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('57','10','3','COMENTARIO','2','Devolver ao utente, não reúne requisitos.','em_tramitacao','2026-09-20 13:28:33');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('58','10','3','ESTADO','2','não reúne requisitos.','devolvido','2026-09-20 13:29:14');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('59','14','3','COMENTARIO',NULL,'Testar Preview, não está a funcionar.','novo','2026-09-23 13:25:30');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('60','14','3','ENCAMINHADO','8','Preview não funciona.','em_tramitacao','2026-09-23 13:26:10');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('61','14','3','ESTADO','8','Preview não funciona.','em_tramitacao','2026-09-23 13:26:46');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('62','7','3','COMENTARIO','8','Ultrapassou o tempo de espera','analise','2026-09-23 17:51:50');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('63','7','3','ENCAMINHADO','3','Verificar pagamento.','em_tramitacao','2026-09-23 17:52:34');
INSERT INTO `documento_tramitacao` (`id`,`documento_id`,`utilizador_id`,`acao`,`area_id`,`comentario`,`estado`,`criado_em`) VALUES ('64','7','3','ESTADO','3','Verificação de pagamento.','em_tramitacao','2026-09-23 17:53:09');


-- Estrutura da tabela `documento_tramitacao_anexos`
CREATE TABLE `documento_tramitacao_anexos` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `tramitacao_id` int unsigned NOT NULL,
  `ficheiro` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ficheiro_original` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `caminho` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tamanho` int DEFAULT NULL,
  `mime_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `tramitacao_id` (`tramitacao_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- Estrutura da tabela `documentos`
CREATE TABLE `documentos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tipo_id` int NOT NULL,
  `titulo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ficheiro` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `caminho` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ficheiro_original` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mime_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tamanho` int DEFAULT NULL,
  `hash` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `criado_por` int NOT NULL,
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP,
  `estado` tinyint(1) DEFAULT '1',
  `estado_atual` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'novo',
  `area_atual_id` int DEFAULT NULL,
  `arquivado_em` datetime DEFAULT NULL,
  `arquivado_por_id` int DEFAULT NULL,
  `area_atual_desde` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_documentos_utilizador` (`criado_por`),
  KEY `tipo_id` (`tipo_id`),
  KEY `fk_documentos_area_atual` (`area_atual_id`),
  KEY `fk_documentos_arquivado_por` (`arquivado_por_id`),
  KEY `fk_documentos_estado` (`estado_atual`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dados da tabela `documentos`
INSERT INTO `documentos` (`id`,`tipo_id`,`titulo`,`ficheiro`,`caminho`,`ficheiro_original`,`mime_type`,`tamanho`,`hash`,`criado_por`,`criado_em`,`estado`,`estado_atual`,`area_atual_id`,`arquivado_em`,`arquivado_por_id`,`area_atual_desde`) VALUES ('1','2','Teste na BD',NULL,NULL,NULL,NULL,NULL,NULL,'93','2026-09-05 00:45:26','1','arquivado','4',NULL,NULL,'2026-09-06 13:07:24');
INSERT INTO `documentos` (`id`,`tipo_id`,`titulo`,`ficheiro`,`caminho`,`ficheiro_original`,`mime_type`,`tamanho`,`hash`,`criado_por`,`criado_em`,`estado`,`estado_atual`,`area_atual_id`,`arquivado_em`,`arquivado_por_id`,`area_atual_desde`) VALUES ('3','6','teste-outro',NULL,NULL,NULL,NULL,NULL,NULL,'92','2026-09-05 00:53:44','1','analise','1',NULL,NULL,'2026-09-05 01:05:17');
INSERT INTO `documentos` (`id`,`tipo_id`,`titulo`,`ficheiro`,`caminho`,`ficheiro_original`,`mime_type`,`tamanho`,`hash`,`criado_por`,`criado_em`,`estado`,`estado_atual`,`area_atual_id`,`arquivado_em`,`arquivado_por_id`,`area_atual_desde`) VALUES ('4','1','teste-2',NULL,NULL,NULL,NULL,NULL,NULL,'92','2026-09-05 01:04:01','1','em_tramitacao','2',NULL,NULL,'2026-09-05 01:21:26');
INSERT INTO `documentos` (`id`,`tipo_id`,`titulo`,`ficheiro`,`caminho`,`ficheiro_original`,`mime_type`,`tamanho`,`hash`,`criado_por`,`criado_em`,`estado`,`estado_atual`,`area_atual_id`,`arquivado_em`,`arquivado_por_id`,`area_atual_desde`) VALUES ('5','29','teste-3',NULL,NULL,NULL,NULL,NULL,NULL,'92','2026-09-05 01:09:29','1','concluido','8',NULL,NULL,'2026-09-06 13:11:43');
INSERT INTO `documentos` (`id`,`tipo_id`,`titulo`,`ficheiro`,`caminho`,`ficheiro_original`,`mime_type`,`tamanho`,`hash`,`criado_por`,`criado_em`,`estado`,`estado_atual`,`area_atual_id`,`arquivado_em`,`arquivado_por_id`,`area_atual_desde`) VALUES ('7','1','Teste pro Anferalta',NULL,NULL,NULL,NULL,NULL,NULL,'94','2026-09-08 00:45:04','1','em_tramitacao','3',NULL,NULL,'2026-09-23 17:52:34');
INSERT INTO `documentos` (`id`,`tipo_id`,`titulo`,`ficheiro`,`caminho`,`ficheiro_original`,`mime_type`,`tamanho`,`hash`,`criado_por`,`criado_em`,`estado`,`estado_atual`,`area_atual_id`,`arquivado_em`,`arquivado_por_id`,`area_atual_desde`) VALUES ('10','4','Continuar os testes de fiabilidade',NULL,NULL,NULL,NULL,NULL,NULL,'93','2026-09-14 14:05:53','1','devolvido','2',NULL,NULL,'2026-09-16 20:46:26');


-- Estrutura da tabela `documentos_logs`
CREATE TABLE `documentos_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `documento_id` int NOT NULL,
  `utilizador_id` int NOT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;



-- Estrutura da tabela `logs_sistema`
CREATE TABLE `logs_sistema` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tipo` varchar(50) NOT NULL,
  `mensagem` text NOT NULL,
  `ficheiro` varchar(255) DEFAULT NULL,
  `linha` int DEFAULT NULL,
  `detalhes` text,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `url` varchar(500) DEFAULT NULL,
  `metodo` varchar(10) DEFAULT NULL,
  `utilizador_id` int DEFAULT NULL,
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FULLTEXT KEY `mensagem` (`mensagem`,`detalhes`)
) ENGINE=MyISAM AUTO_INCREMENT=123 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dados da tabela `logs_sistema`
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('1','error','Constant PDO::MYSQL_ATTR_INIT_COMMAND is deprecated since 8.5, use Pdo\\Mysql::ATTR_INIT_COMMAND instead','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','39',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('2','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('3','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('4','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('5','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('6','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('7','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('8','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('9','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('10','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('11','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('12','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('13','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('14','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('15','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('16','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('17','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('18','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('19','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('20','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('21','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('22','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('23','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('24','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('25','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('26','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('27','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('28','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('29','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('30','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('31','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('32','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('33','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('34','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('35','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('36','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('37','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('38','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('39','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('40','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('41','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('42','error','PDO::quote(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php','117',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('43','backup_sucesso','Backup BD: /home/anferalta/www/anferaltadocs/backups/BaseDados/2026/09/backup_db_2026-09-04_21-19-59.sql.zip','/home/anferalta/www/anferaltadocs/App/Services/BackupLogger.php','31',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:19:59');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('44','error','Cannot modify header information - headers already sent by (output started at /home/anferalta/www/anferaltadocs/App/Services/DatabaseBackupService.php:117)','/home/anferalta/www/anferaltadocs/App/Core/BaseController.php','163',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:20:00');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('45','backup_sucesso','Backup BD: /home/anferalta/www/anferaltadocs/backups/BaseDados/2026/09/backup_db_2026-09-04_21-30-08.sql.zip','/home/anferalta/www/anferaltadocs/App/Services/BackupLogger.php','31',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:30:08');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('46','error','unlink(/home/anferalta/www/anferaltadocs/backups/Ficheiros/2026/09/backup_files_2026-09-04_21-30-44.zip): No such file or directory','/home/anferalta/www/anferaltadocs/App/Services/FileBackupService.php','136',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/files/criar','GET','3','2026-09-04 21:30:44');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('47','backup_erro','Nenhum ficheiro novo ou alterado para backup.','/home/anferalta/www/anferaltadocs/App/Services/BackupLogger.php','31',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/files/criar','GET','3','2026-09-04 21:30:44');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('48','error','unlink(/home/anferalta/www/anferaltadocs/backups/Ficheiros/2026/09/backup_files_2026-09-04_21-31-44.zip): No such file or directory','/home/anferalta/www/anferaltadocs/App/Services/FileBackupService.php','136',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/files/criar','GET','3','2026-09-04 21:31:44');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('49','backup_erro','Nenhum ficheiro novo ou alterado para backup.','/home/anferalta/www/anferaltadocs/App/Services/BackupLogger.php','31',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/files/criar','GET','3','2026-09-04 21:31:44');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('50','backup_sucesso','Backup BD: /home/anferalta/www/anferaltadocs/backups/BaseDados/2026/09/backup_db_2026-09-04_21-32-05.sql.zip','/home/anferalta/www/anferaltadocs/App/Services/BackupLogger.php','31',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-04 21:32:05');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('51','error','Undefined property: App\\Models\\DocumentoFicheiro::$mime_type','/home/anferalta/www/anferaltadocs/App/Controllers/Admin/DocumentosAdminController.php','975',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/documentos/anexo/abrir/1','GET','3','2026-09-05 00:49:19');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('52','error','Undefined property: App\\Models\\DocumentoFicheiro::$mime_type','/home/anferalta/www/anferaltadocs/App/Controllers/Admin/DocumentosAdminController.php','975',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/documentos/anexo/abrir/1','GET','3','2026-09-05 00:49:56');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('53','error','Undefined property: App\\Models\\DocumentoFicheiro::$mime_type','/home/anferalta/www/anferaltadocs/App/Controllers/Admin/DocumentosAdminController.php','975',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/documentos/anexo/abrir/3','GET','3','2026-09-05 01:06:02');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('54','error','Undefined property: App\\Models\\DocumentoFicheiro::$mime_type','/home/anferalta/www/anferaltadocs/App/Controllers/Admin/DocumentosAdminController.php','975',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/documentos/anexo/abrir/4','GET','3','2026-09-05 01:06:32');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('55','error','Undefined property: App\\Models\\DocumentoFicheiro::$mime_type','/home/anferalta/www/anferaltadocs/App/Controllers/Admin/DocumentosAdminController.php','975',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/documentos/anexo/abrir/4','GET','3','2026-09-05 22:26:27');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('56','error','Undefined variable $Router','/home/anferalta/www/anferaltadocs/routes/admin.php','112',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/documentos/exportar-csv?','GET','3','2026-09-07 19:55:28');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('57','error','Undefined variable $Router','/home/anferalta/www/anferaltadocs/routes/admin.php','112',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/documentos/exportar-csv?','GET','3','2026-09-07 19:58:13');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('58','error','fputcsv(): the $escape parameter must be provided as its default value will change','/home/anferalta/www/anferaltadocs/App/Controllers/Admin/DocumentosAdminController.php','757',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/documentos/exportar-csv?','GET','3','2026-09-07 20:01:58');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('59','error','fputcsv(): the $escape parameter must be provided as its default value will change','/home/anferalta/www/anferaltadocs/App/Controllers/Admin/DocumentosAdminController.php','761',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/documentos/exportar-csv?','GET','3','2026-09-07 20:01:58');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('60','error','fputcsv(): the $escape parameter must be provided as its default value will change','/home/anferalta/www/anferaltadocs/App/Controllers/Admin/DocumentosAdminController.php','761',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/documentos/exportar-csv?','GET','3','2026-09-07 20:01:58');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('61','error','fputcsv(): the $escape parameter must be provided as its default value will change','/home/anferalta/www/anferaltadocs/App/Controllers/Admin/DocumentosAdminController.php','761',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/documentos/exportar-csv?','GET','3','2026-09-07 20:01:58');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('62','error','fputcsv(): the $escape parameter must be provided as its default value will change','/home/anferalta/www/anferaltadocs/App/Controllers/Admin/DocumentosAdminController.php','761',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/documentos/exportar-csv?','GET','3','2026-09-07 20:01:58');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('63','error','fputcsv(): the $escape parameter must be provided as its default value will change','/home/anferalta/www/anferaltadocs/App/Controllers/Admin/DocumentosAdminController.php','761',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/documentos/exportar-csv?','GET','3','2026-09-07 20:01:58');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('64','error','fputcsv(): the $escape parameter must be provided as its default value will change','/home/anferalta/www/anferaltadocs/App/Controllers/Admin/DocumentosAdminController.php','761',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/documentos/exportar-csv?','GET','3','2026-09-07 20:01:58');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('65','error','fputcsv(): the $escape parameter must be provided as its default value will change','/home/anferalta/www/anferaltadocs/App/Controllers/Admin/DocumentosAdminController.php','757',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/documentos/exportar-csv?','GET','3','2026-09-07 20:02:33');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('66','error','fputcsv(): the $escape parameter must be provided as its default value will change','/home/anferalta/www/anferaltadocs/App/Controllers/Admin/DocumentosAdminController.php','761',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/documentos/exportar-csv?','GET','3','2026-09-07 20:02:33');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('67','error','fputcsv(): the $escape parameter must be provided as its default value will change','/home/anferalta/www/anferaltadocs/App/Controllers/Admin/DocumentosAdminController.php','761',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/documentos/exportar-csv?','GET','3','2026-09-07 20:02:33');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('68','error','fputcsv(): the $escape parameter must be provided as its default value will change','/home/anferalta/www/anferaltadocs/App/Controllers/Admin/DocumentosAdminController.php','761',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/documentos/exportar-csv?','GET','3','2026-09-07 20:02:33');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('69','error','fputcsv(): the $escape parameter must be provided as its default value will change','/home/anferalta/www/anferaltadocs/App/Controllers/Admin/DocumentosAdminController.php','761',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/documentos/exportar-csv?','GET','3','2026-09-07 20:02:33');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('70','error','fputcsv(): the $escape parameter must be provided as its default value will change','/home/anferalta/www/anferaltadocs/App/Controllers/Admin/DocumentosAdminController.php','761',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/documentos/exportar-csv?','GET','3','2026-09-07 20:02:33');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('71','error','fputcsv(): the $escape parameter must be provided as its default value will change','/home/anferalta/www/anferaltadocs/App/Controllers/Admin/DocumentosAdminController.php','761',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/documentos/exportar-csv?','GET','3','2026-09-07 20:02:33');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('72','error','fputcsv(): the $escape parameter must be provided as its default value will change','/home/anferalta/www/anferaltadocs/App/Controllers/Admin/DocumentosAdminController.php','757',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/documentos/exportar-csv?','GET','3','2026-09-07 20:03:56');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('73','error','fputcsv(): the $escape parameter must be provided as its default value will change','/home/anferalta/www/anferaltadocs/App/Controllers/Admin/DocumentosAdminController.php','761',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/documentos/exportar-csv?','GET','3','2026-09-07 20:03:56');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('74','error','fputcsv(): the $escape parameter must be provided as its default value will change','/home/anferalta/www/anferaltadocs/App/Controllers/Admin/DocumentosAdminController.php','761',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/documentos/exportar-csv?','GET','3','2026-09-07 20:03:56');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('75','error','fputcsv(): the $escape parameter must be provided as its default value will change','/home/anferalta/www/anferaltadocs/App/Controllers/Admin/DocumentosAdminController.php','761',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/documentos/exportar-csv?','GET','3','2026-09-07 20:03:56');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('76','error','fputcsv(): the $escape parameter must be provided as its default value will change','/home/anferalta/www/anferaltadocs/App/Controllers/Admin/DocumentosAdminController.php','761',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/documentos/exportar-csv?','GET','3','2026-09-07 20:03:56');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('77','error','fputcsv(): the $escape parameter must be provided as its default value will change','/home/anferalta/www/anferaltadocs/App/Controllers/Admin/DocumentosAdminController.php','761',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/documentos/exportar-csv?','GET','3','2026-09-07 20:03:56');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('78','error','fputcsv(): the $escape parameter must be provided as its default value will change','/home/anferalta/www/anferaltadocs/App/Controllers/Admin/DocumentosAdminController.php','761',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/documentos/exportar-csv?','GET','3','2026-09-07 20:03:56');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('79','error','Undefined property: App\\Models\\Documento::$utilizador_id','/home/anferalta/www/anferaltadocs/App/Controllers/Admin/DocumentosAdminController.php','1022',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/documentos/arquivado/1/recuperar','POST','3','2026-09-07 21:05:26');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('80','backup_sucesso','Backup BD: /home/anferalta/www/anferaltadocs/backups/BaseDados/2026/09/backup_db_2026-09-08_20-31-39.sql.zip','/home/anferalta/www/anferaltadocs/App/Services/BackupLogger.php','31',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','/admin/backups/bd/criar','GET','93','2026-09-08 20:31:39');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('81','backup_sucesso','Backup FILES: /home/anferalta/www/anferaltadocs/backups/Ficheiros/2026/09/backup_files_2026-09-08_20-31-47.zip','/home/anferalta/www/anferaltadocs/App/Services/BackupLogger.php','31',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','/admin/backups/files/criar','GET','93','2026-09-08 20:31:48');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('82','error','trim(): Passing null to parameter #1 ($string) of type string is deprecated','/home/anferalta/www/anferaltadocs/App/Core/Router.php','86',NULL,'34.14.1.41','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36','//xmlrpc.php?rsd','GET',NULL,'2026-09-11 10:56:07');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('83','error','Undefined variable $anexo','/home/anferalta/www/anferaltadocs/App/Controllers/DocumentosUserController.php','217',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','/documentos/anexo/abrir/15','GET','93','2026-09-11 20:24:36');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('84','error','Attempt to read property \"caminho\" on null','/home/anferalta/www/anferaltadocs/App/Controllers/DocumentosUserController.php','217',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','/documentos/anexo/abrir/15','GET','93','2026-09-11 20:24:36');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('85','error','Undefined variable $anexo','/home/anferalta/www/anferaltadocs/App/Controllers/DocumentosUserController.php','217',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','/documentos/anexo/abrir/15','GET','93','2026-09-11 20:24:36');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('86','error','Attempt to read property \"ficheiro\" on null','/home/anferalta/www/anferaltadocs/App/Controllers/DocumentosUserController.php','217',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','/documentos/anexo/abrir/15','GET','93','2026-09-11 20:24:36');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('87','backup_sucesso','Backup BD: /home/anferalta/www/anferaltadocs/backups/BaseDados/2026/09/backup_db_2026-09-14_17-54-25.sql.zip','/home/anferalta/www/anferaltadocs/App/Services/BackupLogger.php','31',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','/admin/backups/bd/criar','GET','97','2026-09-14 17:54:25');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('88','backup_sucesso','Backup FILES: /home/anferalta/www/anferaltadocs/backups/Ficheiros/2026/09/backup_files_2026-09-14_17-54-31.zip','/home/anferalta/www/anferaltadocs/App/Services/BackupLogger.php','31',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36 Edg/152.0.0.0','/admin/backups/files/criar','GET','97','2026-09-14 17:54:31');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('89','erro','Undefined variable $router','/home/anferalta/www/anferaltadocs/routes/admin.php','8',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','/','GET',NULL,'2026-09-15 22:37:13');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('90','excecao','Call to a member function get() on null','/home/anferalta/www/anferaltadocs/routes/admin.php','8','#0 /home/anferalta/www/index.php(22): require()\n#1 {main}','95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','/','GET',NULL,'2026-09-15 22:37:13');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('91','erro','Undefined variable $router','/home/anferalta/www/anferaltadocs/routes/public.php','4',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','/','GET',NULL,'2026-09-15 22:39:35');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('92','excecao','Call to a member function get() on null','/home/anferalta/www/anferaltadocs/routes/public.php','4','#0 /home/anferalta/www/anferaltadocs/routes/index.php(3): require()\n#1 /home/anferalta/www/index.php(22): require(\'/home/anferalta...\')\n#2 {main}','95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','/','GET',NULL,'2026-09-15 22:39:35');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('93','erro','Undefined variable $router','/home/anferalta/www/anferaltadocs/routes/public.php','4',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','/','GET',NULL,'2026-09-15 22:44:58');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('94','excecao','Call to a member function get() on null','/home/anferalta/www/anferaltadocs/routes/public.php','4','#0 /home/anferalta/www/anferaltadocs/routes/index.php(3): require()\n#1 /home/anferalta/www/index.php(28): require(\'/home/anferalta...\')\n#2 {main}','95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','/','GET',NULL,'2026-09-15 22:44:58');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('95','erro','Undefined variable $router','/home/anferalta/www/anferaltadocs/routes/public.php','4',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','/','GET',NULL,'2026-09-15 22:49:19');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('96','excecao','Call to a member function get() on null','/home/anferalta/www/anferaltadocs/routes/public.php','4','#0 /home/anferalta/www/anferaltadocs/routes/index.php(3): require()\n#1 /home/anferalta/www/index.php(28): require(\'/home/anferalta...\')\n#2 {main}','95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','/','GET',NULL,'2026-09-15 22:49:19');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('97','erro','Undefined variable $router','/home/anferalta/www/anferaltadocs/routes/public.php','4',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','/','GET',NULL,'2026-09-15 22:49:24');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('98','excecao','Call to a member function get() on null','/home/anferalta/www/anferaltadocs/routes/public.php','4','#0 /home/anferalta/www/anferaltadocs/routes/index.php(3): require()\n#1 /home/anferalta/www/index.php(28): require(\'/home/anferalta...\')\n#2 {main}','95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','/','GET',NULL,'2026-09-15 22:49:24');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('99','erro','Undefined variable $router','/home/anferalta/www/anferaltadocs/routes/public.php','4',NULL,'105.172.167.48','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.2 Mobile/15E148 Safari/604.1','/','GET',NULL,'2026-09-15 22:52:01');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('100','excecao','Call to a member function get() on null','/home/anferalta/www/anferaltadocs/routes/public.php','4','#0 /home/anferalta/www/anferaltadocs/routes/index.php(3): require()\n#1 /home/anferalta/www/index.php(28): require(\'/home/anferalta...\')\n#2 {main}','105.172.167.48','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.2 Mobile/15E148 Safari/604.1','/','GET',NULL,'2026-09-15 22:52:01');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('101','erro','Undefined variable $router','/home/anferalta/www/anferaltadocs/routes/public.php','4',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','/','GET',NULL,'2026-09-15 22:56:12');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('102','excecao','Call to a member function get() on null','/home/anferalta/www/anferaltadocs/routes/public.php','4','#0 /home/anferalta/www/anferaltadocs/routes/index.php(3): require()\n#1 /home/anferalta/www/index.php(28): require(\'/home/anferalta...\')\n#2 {main}','95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','/','GET',NULL,'2026-09-15 22:56:12');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('103','erro','file_get_contents(/home/anferalta/www/anferaltadocs/routes/anferaltadocs/routes/index.php): Failed to open stream: No such file or directory','/home/anferalta/www/anferaltadocs/routes/index.php','4',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','/','GET',NULL,'2026-09-15 22:59:47');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('104','erro','Undefined variable $router','/home/anferalta/www/anferaltadocs/routes/public.php','4',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','/','GET',NULL,'2026-09-15 23:04:45');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('105','excecao','Call to a member function get() on null','/home/anferalta/www/anferaltadocs/routes/public.php','4','#0 /home/anferalta/www/anferaltadocs/routes/index.php(2): require()\n#1 /home/anferalta/www/index.php(28): require(\'/home/anferalta...\')\n#2 {main}','95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','/','GET',NULL,'2026-09-15 23:04:45');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('106','erro','Undefined variable $router','/home/anferalta/www/anferaltadocs/routes/admin.php','8',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','/','GET',NULL,'2026-09-15 23:06:05');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('107','excecao','Call to a member function get() on null','/home/anferalta/www/anferaltadocs/routes/admin.php','8','#0 /home/anferalta/www/index.php(28): require()\n#1 {main}','95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0','/','GET',NULL,'2026-09-15 23:06:05');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('108','erro','Undefined variable $router','/home/anferalta/www/anferaltadocs/routes/admin.php','8',NULL,'105.172.71.42','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.2 Mobile/15E148 Safari/604.1','/','GET',NULL,'2026-09-15 23:09:09');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('109','excecao','Call to a member function get() on null','/home/anferalta/www/anferaltadocs/routes/admin.php','8','#0 /home/anferalta/www/index.php(28): require()\n#1 {main}','105.172.71.42','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.2 Mobile/15E148 Safari/604.1','/','GET',NULL,'2026-09-15 23:09:09');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('110','erro','Undefined variable $router','/home/anferalta/www/anferaltadocs/routes/admin.php','8',NULL,'105.172.71.42','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.2 Mobile/15E148 Safari/604.1','/','GET',NULL,'2026-09-15 23:09:29');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('111','excecao','Call to a member function get() on null','/home/anferalta/www/anferaltadocs/routes/admin.php','8','#0 /home/anferalta/www/index.php(28): require()\n#1 {main}','105.172.71.42','Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.2 Mobile/15E148 Safari/604.1','/','GET',NULL,'2026-09-15 23:09:29');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('112','backup_sucesso','Backup FILES: /home/anferalta/www/anferaltadocs/backups/Ficheiros/2026/09/backup_files_2026-09-17_20-16-45.zip','/home/anferalta/www/anferaltadocs/App/Services/BackupLogger.php','31',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36','/admin/backups/files/criar','GET','3','2026-09-17 20:16:45');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('113','backup_sucesso','Backup BD: /home/anferalta/www/anferaltadocs/backups/BaseDados/2026/09/backup_db_2026-09-23_18-09-07.sql.zip','/home/anferalta/www/anferaltadocs/App/Services/BackupLogger.php','31',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-23 18:09:07');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('114','backup_erro','Ficheiro ignorado (corrompido ou vazio)','/home/anferalta/www/anferaltadocs/App/Services/BackupLogger.php','31',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36','/admin/backups/files/criar','GET','3','2026-09-23 18:09:16');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('115','backup_erro','Ficheiro ignorado (corrompido ou vazio)','/home/anferalta/www/anferaltadocs/App/Services/BackupLogger.php','31',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36','/admin/backups/files/criar','GET','3','2026-09-23 18:09:16');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('116','backup_sucesso','Backup FILES: /home/anferalta/www/anferaltadocs/backups/Ficheiros/2026/09/backup_files_2026-09-23_18-09-16.zip','/home/anferalta/www/anferaltadocs/App/Services/BackupLogger.php','31',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36','/admin/backups/files/criar','GET','3','2026-09-23 18:09:20');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('117','backup_sucesso','Backup BD: /home/anferalta/www/anferaltadocs/backups/BaseDados/2026/09/backup_db_2026-09-23_19-48-42.zip','/home/anferalta/www/anferaltadocs/App/Services/BackupLogger.php','31',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-23 19:48:42');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('118','backup_sucesso','Backup automático antes do restauro.','/home/anferalta/www/anferaltadocs/App/Services/BackupLogger.php','31',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36','/admin/backups/bd/restaurar/2026---09---backup_db_2026-09-23_19-48-42.zip','POST','3','2026-09-23 20:21:58');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('119','backup_erro','Falha no restauro: Erro ao executar comando SQL: SQLSTATE[42S01]: Base table or view already exists: 1050 Table \'auditoria\' already exists','/home/anferalta/www/anferaltadocs/App/Services/BackupLogger.php','31',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36','/admin/backups/bd/restaurar/2026---09---backup_db_2026-09-23_19-48-42.zip','POST','3','2026-09-23 20:21:58');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('120','backup_sucesso','Backup BD: /home/anferalta/www/anferaltadocs/backups/BaseDados/2026/09/backup_db_2026-09-23_20-27-57.zip','/home/anferalta/www/anferaltadocs/App/Services/BackupLogger.php','31',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36','/admin/backups/bd/criar','GET','3','2026-09-23 20:27:57');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('121','backup_sucesso','Backup automático antes do restauro.','/home/anferalta/www/anferaltadocs/App/Services/BackupLogger.php','31',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36','/admin/backups/bd/restaurar/2026---09---backup_db_2026-09-23_20-27-57.zip','POST','3','2026-09-23 20:28:05');
INSERT INTO `logs_sistema` (`id`,`tipo`,`mensagem`,`ficheiro`,`linha`,`detalhes`,`ip`,`user_agent`,`url`,`metodo`,`utilizador_id`,`criado_em`) VALUES ('122','backup_erro','Falha no restauro: Erro ao executar comando SQL: SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry \'2\' for key \'auditoria.PRIMARY\'','/home/anferalta/www/anferaltadocs/App/Services/BackupLogger.php','31',NULL,'95.92.119.110','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36','/admin/backups/bd/restaurar/2026---09---backup_db_2026-09-23_20-27-57.zip','POST','3','2026-09-23 20:28:05');


-- Estrutura da tabela `notificacoes`
CREATE TABLE `notificacoes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `utilizador_id` int unsigned NOT NULL,
  `documento_id` bigint unsigned DEFAULT NULL,
  `tipo` varchar(50) NOT NULL,
  `mensagem` text NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  `lida` tinyint(1) NOT NULL DEFAULT '0',
  `criado_em` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dados da tabela `notificacoes`
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('1','92','3','comentario','O documento \'teste-outro\' recebeu um comentário.','/admin/tramitacao/3','0','2026-09-05 01:04:47');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('2','92','3','estado','O estado do documento \'teste-outro\' foi alterado para \'analise\'.','/admin/tramitacao/3','0','2026-09-05 01:05:47');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('3','92','4','comentario','O documento \'teste-2\' recebeu um comentário.','/admin/tramitacao/4','0','2026-09-05 01:07:23');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('4','92','4','estado','O estado do documento \'teste-2\' foi alterado para \'em_tramitacao\'.','/admin/tramitacao/4','0','2026-09-05 01:08:17');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('5','92','5','estado','O estado do documento \'teste-3\' foi alterado para \'em_tramitacao\'.','/admin/tramitacao/5','0','2026-09-06 11:03:58');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('6','93','1','comentario','O documento \'Teste na BD\' recebeu um comentário.','/admin/tramitacao/1','0','2026-09-06 13:06:43');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('7','93','1','estado','O estado do documento \'Teste na BD\' foi alterado para \'em_tramitacao\'.','/admin/tramitacao/1','0','2026-09-06 13:07:55');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('8','93','2','comentario','O documento \'Novo teste da BD\' recebeu um comentário.','/admin/tramitacao/2','0','2026-09-06 13:08:52');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('9','93','2','estado','O estado do documento \'Novo teste da BD\' foi alterado para \'analise\'.','/admin/tramitacao/2','0','2026-09-06 13:09:50');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('10','92','5','comentario','O documento \'teste-3\' recebeu um comentário.','/admin/tramitacao/5','0','2026-09-06 13:11:03');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('11','92','5','estado','O estado do documento \'teste-3\' foi alterado para \'concluido\'.','/admin/tramitacao/5','0','2026-09-06 13:12:25');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('12','93','1','comentario','O documento \'Teste na BD\' recebeu um comentário.','/admin/tramitacao/1','0','2026-09-07 12:23:50');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('13','93','1','estado','O estado do documento \'Teste na BD\' foi alterado para \'concluido\'.','/admin/tramitacao/1','0','2026-09-07 12:24:16');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('14','93','1','estado','O documento \'Teste na BD\' foi arquivado.','/admin/tramitacao/1','0','2026-09-07 12:24:22');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('15','93','2','comentario','O documento \'Novo teste da BD\' recebeu um comentário.','/admin/tramitacao/2','0','2026-09-07 12:26:08');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('16','93','2','estado','O estado do documento \'Novo teste da BD\' foi alterado para \'pendente\'.','/admin/tramitacao/2','0','2026-09-07 12:26:45');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('17','93','6','comentario','O documento \'Teste do CSRF\' recebeu um comentário.','/admin/tramitacao/6','0','2026-09-07 12:58:51');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('18','92','3','comentario','O documento \'teste-outro\' recebeu um comentário.','/admin/tramitacao/3','0','2026-09-07 20:34:10');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('19','93','6','estado','O estado do documento \'Teste do CSRF\' foi alterado para \'devolvido\'.','/admin/tramitacao/6','0','2026-09-07 20:56:26');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('20','93','1','comentario','O documento \'Teste na BD\' recebeu um comentário.','/admin/tramitacao/1','0','2026-09-07 21:06:00');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('21','93','1','estado','O estado do documento \'Teste na BD\' foi alterado para \'teste\'.','/admin/tramitacao/1','0','2026-09-07 21:29:27');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('22','93','1','comentario','O documento \'Teste na BD\' recebeu um comentário.','/admin/tramitacao/1','0','2026-09-07 21:31:58');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('23','93','1','estado','O estado do documento \'Teste na BD\' foi alterado para \'concluido\'.','/admin/tramitacao/1','0','2026-09-07 21:32:32');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('24','94','7','estado','O estado do documento \'Teste pro Anferalta\' foi alterado para \'analise\'.','/admin/tramitacao/7','0','2026-09-08 00:52:11');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('25','93','6','estado','O estado do documento \'Teste do CSRF\' foi alterado para \'concluido\'.','/admin/tramitacao/6','0','2026-09-09 16:56:31');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('26','93','6','estado','O documento \'Teste do CSRF\' foi arquivado.','/admin/tramitacao/6','0','2026-09-09 16:56:37');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('27','94','7','comentario','O documento \'Teste pro Anferalta\' recebeu um comentário.','/admin/tramitacao/7','0','2026-09-09 17:10:32');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('28','93','8','comentario','O documento \'Verificar fluxo de tramitação\' recebeu um comentário.','/admin/tramitacao/8','0','2026-09-14 11:54:36');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('29','93','8','estado','O estado do documento \'Verificar fluxo de tramitação\' foi alterado para \'em_tramitacao\'.','/admin/tramitacao/8','0','2026-09-14 11:55:57');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('30','93','9','comentario','O documento \'Teste\' recebeu um comentário.','/admin/tramitacao/9','0','2026-09-14 14:07:18');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('31','93','9','estado','O estado do documento \'Teste\' foi alterado para \'devolvido\'.','/admin/tramitacao/9','0','2026-09-14 14:08:13');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('32','93','10','comentario','O documento \'Continuar os testes de fiabilidade\' recebeu um comentário.','/admin/tramitacao/10','0','2026-09-14 15:56:18');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('33','93','11','comentario','O documento \'Teste de documentos docx\' recebeu um comentário.','/admin/tramitacao/11','0','2026-09-15 12:59:26');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('34','93','11','estado','O estado do documento \'Teste de documentos docx\' foi alterado para \'pendente\'.','/admin/tramitacao/11','0','2026-09-15 13:00:42');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('35','93','10','comentario','O documento \'Continuar os testes de fiabilidade\' recebeu um comentário.','/admin/tramitacao/10','0','2026-09-15 14:47:27');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('36','93','8','comentario','O documento \'Verificar fluxo de tramitação\' recebeu um comentário.','/admin/tramitacao/8','0','2026-09-17 19:01:21');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('37','93','8','estado','O documento \'Verificar fluxo de tramitação\' foi arquivado.','/admin/tramitacao/8','0','2026-09-17 19:01:28');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('38','93','12','comentario','O documento \'Preview não funciona\' recebeu um comentário.','/admin/tramitacao/12','0','2026-09-17 19:03:07');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('39','93','1','comentario','O documento \'Teste na BD\' recebeu um comentário.','/admin/tramitacao/1','0','2026-09-20 13:26:19');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('40','93','1','estado','O documento \'Teste na BD\' foi arquivado.','/admin/tramitacao/1','0','2026-09-20 13:26:27');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('41','93','10','comentario','O documento \'Continuar os testes de fiabilidade\' recebeu um comentário.','/admin/tramitacao/10','0','2026-09-20 13:28:33');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('42','93','10','estado','O estado do documento \'Continuar os testes de fiabilidade\' foi alterado para \'devolvido\'.','/admin/tramitacao/10','0','2026-09-20 13:29:14');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('43','93','14','comentario','O documento \'Teste preview.\' recebeu um comentário.','/admin/tramitacao/14','0','2026-09-23 13:25:30');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('44','93','14','estado','O estado do documento \'Teste preview.\' foi alterado para \'em_tramitacao\'.','/admin/tramitacao/14','0','2026-09-23 13:26:46');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('45','94','7','comentario','O documento \'Teste pro Anferalta\' recebeu um comentário.','/admin/tramitacao/7','0','2026-09-23 17:51:50');
INSERT INTO `notificacoes` (`id`,`utilizador_id`,`documento_id`,`tipo`,`mensagem`,`url`,`lida`,`criado_em`) VALUES ('46','94','7','estado','O estado do documento \'Teste pro Anferalta\' foi alterado para \'em_tramitacao\'.','/admin/tramitacao/7','0','2026-09-23 17:53:09');


-- Estrutura da tabela `password_resets`
CREATE TABLE `password_resets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `criado_em` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `email` (`email`(250)),
  KEY `token` (`token`(250))
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dados da tabela `password_resets`
INSERT INTO `password_resets` (`id`,`email`,`token`,`criado_em`) VALUES ('1','almeida.marius@gmail.com','f6b81f455621e85cecbd3e89ba4a284ed0f3b19d995f3c2a939366ef99fc906c','2026-09-04 16:10:50');
INSERT INTO `password_resets` (`id`,`email`,`token`,`criado_em`) VALUES ('2','antonio.almeida@anferalta.com','67a2312d4af6acfdbe11d84767fbdfc75486d584c7d7ec47a9d504b92ebb8492','2026-09-04 17:06:49');
INSERT INTO `password_resets` (`id`,`email`,`token`,`criado_em`) VALUES ('3','cristianocaetanock10@gmail.com','06297212f9abd18670c3d3b4ffed84e22c2b979661186b12f49d6b650c78c447','2026-09-06 00:53:45');
INSERT INTO `password_resets` (`id`,`email`,`token`,`criado_em`) VALUES ('4','anferalta@gmail.com','80670924dbe9125e533efcfa3dfeab9e76a792c3c6d18ad43b733227ad118af2','2026-09-14 15:43:31');
INSERT INTO `password_resets` (`id`,`email`,`token`,`criado_em`) VALUES ('5','daniel_almeida079@hotmail.com','58df7886feafcf7cc61572841a14cfaaf75d544f80cbed3a39d112adaad90982','2026-09-15 18:37:57');
INSERT INTO `password_resets` (`id`,`email`,`token`,`criado_em`) VALUES ('6','herbertosimoes64@gmail.com','b7f4f971ebaca7f530eef484a28480723fbf4b0fe73fdd939ef8787cb17044c8','2026-09-15 19:15:11');
INSERT INTO `password_resets` (`id`,`email`,`token`,`criado_em`) VALUES ('7','ljsdiamututa1@hotmail.com','3fe006e4912f5e020cd4fb132a7a2b4a498b8caa1f314c00636cd1822a959b99','2026-09-15 20:31:55');
INSERT INTO `password_resets` (`id`,`email`,`token`,`criado_em`) VALUES ('8','hugahuga128@gmail.com','81334d307f7a2bcdf332d71ab4aa4d5e99aab8dc379acb0b900aca7157ca664e','2026-09-16 17:18:48');
INSERT INTO `password_resets` (`id`,`email`,`token`,`criado_em`) VALUES ('9','anferalta@outlook.com','57570c1ed1f920c032800acc41b93ffe21763afe40d6dae37febfe6a88fc46b1','2026-09-17 20:05:59');


-- Estrutura da tabela `perfis`
CREATE TABLE `perfis` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  `criado_em` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nome` (`nome`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dados da tabela `perfis`
INSERT INTO `perfis` (`id`,`nome`,`descricao`,`ativo`,`criado_em`) VALUES ('1','admin','Administrador do sistema','1','2026-02-17 18:03:49');
INSERT INTO `perfis` (`id`,`nome`,`descricao`,`ativo`,`criado_em`) VALUES ('3','Gestor','Gestor de Sistema','1','2026-02-24 20:23:10');
INSERT INTO `perfis` (`id`,`nome`,`descricao`,`ativo`,`criado_em`) VALUES ('4','Utilizador','Utilizador de Sistema','1','2026-02-24 20:36:31');
INSERT INTO `perfis` (`id`,`nome`,`descricao`,`ativo`,`criado_em`) VALUES ('9','Supervisor','Supervisor de Sistema','1','2026-02-25 14:00:35');


-- Estrutura da tabela `perfis_permissoes`
CREATE TABLE `perfis_permissoes` (
  `perfil_id` int NOT NULL,
  `permissao_id` int NOT NULL,
  PRIMARY KEY (`perfil_id`,`permissao_id`),
  KEY `fk_permissao` (`permissao_id`),
  CONSTRAINT `fk_perfil` FOREIGN KEY (`perfil_id`) REFERENCES `perfis` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_permissao` FOREIGN KEY (`permissao_id`) REFERENCES `permissoes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dados da tabela `perfis_permissoes`
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1183');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1183');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1183');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1184');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1184');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1184');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1185');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1186');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1187');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1188');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1189');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1190');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1191');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1192');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1193');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1194');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1195');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1196');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1197');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1198');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1198');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1198');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1199');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1199');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1199');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1200');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1201');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1202');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1203');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1204');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1205');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1205');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1205');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1206');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1206');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1206');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1207');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1208');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1209');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1209');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1210');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1211');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1211');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('4','1211');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1211');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1212');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('4','1212');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1213');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('4','1213');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1213');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1214');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('4','1214');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1215');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('4','1215');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1215');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1216');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1217');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1218');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1219');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1220');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1220');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1220');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1221');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1222');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1222');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1222');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1223');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1224');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1225');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1225');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1226');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1227');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1227');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1228');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1229');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1229');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1236');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1236');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1237');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1267');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1267');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1267');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1268');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1268');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1268');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1269');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1270');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1271');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1272');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1274');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1274');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1274');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1276');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1276');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1276');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1277');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1277');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1277');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1278');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1278');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1278');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1280');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1280');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1280');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1281');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1286');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1288');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1288');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1288');


-- Estrutura da tabela `permissoes`
CREATE TABLE `permissoes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `codigo` varchar(100) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=1291 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dados da tabela `permissoes`
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1183','admin.dashboard.ver','Aceder ao dashboard');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1184','admin.utilizadores.ver','Listar utilizadores');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1185','admin.utilizadores.criar','Criar utilizadores');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1186','admin.utilizadores.editar','Editar utilizadores');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1187','admin.utilizadores.apagar','Apagar utilizadores');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1188','admin.perfis.ver','Listar perfis');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1189','admin.perfis.criar','Criar perfis');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1190','admin.perfis.editar','Editar perfis');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1191','admin.perfis.apagar','Apagar perfis');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1192','admin.perfis.permissoes','Gerir permissões do perfil');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1193','admin.permissoes.ver','Listar permissões');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1194','admin.permissoes.criar','Criar permissões');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1195','admin.permissoes.editar','Editar permissões');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1196','admin.permissoes.apagar','Apagar permissões');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1197','admin.permissoes.sincronizar','Sincronizar permissões');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1198','admin.backups.bd.ver','Ver backups da base de dados');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1199','admin.backups.bd.criar','Criar backup da base de dados');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1200','admin.backups.bd.download','Descarregar backup da base de dados');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1201','admin.backups.bd.apagar','Apagar backup da base de dados');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1202','admin.backups.bd.restaurar','Restaurar backup da base de dados');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1203','admin.backups.bd.restaurar.confirmar','Confirmar restauro da base de dados');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1204','admin.backups.bd.restaurar.executar','Executar restauro da base de dados');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1205','admin.backups.files.ver','Ver backups de ficheiros');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1206','admin.backups.files.criar','Criar backup de ficheiros');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1207','admin.backups.files.download','Descarregar backup de ficheiros');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1208','admin.backups.files.apagar','Apagar backup de ficheiros');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1209','admin.backups.agendamentos.ver','Ver agendamentos de backups');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1210','admin.backups.agendamentos.editar','Editar agendamentos de backups');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1211','admin.documentos.ver','Listar documentos');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1212','admin.documentos.criar','Criar documentos');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1213','admin.documentos.editar','Editar documentos');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1214','admin.documentos.apagar','Apagar documentos');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1215','admin.documentos.download','Descarregar documentos');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1216','admin.documento-tipos.ver','Listar tipos de documento');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1217','admin.documento-tipos.criar','Criar tipos de documento');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1218','admin.documento-tipos.editar','Editar tipos de documento');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1219','admin.documento-tipos.apagar','Apagar tipos de documento');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1220','admin.logs.ver','Ver logs do sistema');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1221','admin.logs.apagar','Apagar logs do sistema');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1222','admin.auditoria.ver','Ver auditoria do sistema');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1223','admin.config.ver','Ver configurações');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1224','admin.config.editar','Editar configurações');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1225','documentos.ver','Ver documentos');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1226','documentos.criar','Criar documentos');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1227','documentos.editar','Editar documentos');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1228','documentos.apagar','Apagar documentos');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1229','documentos.download','Descarregar documentos');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1236','admin.utilizadores.aprovar','Aprovar utilizadores');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1237','admin.utilizadores.bloquear','Bloquear utilizadores');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1267','admin.tramitacao.ver','Aceder à tramitação');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1268','admin.tramitacao.dashboard','Ver dashboard de tramitação');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1269','admin.tramitacao.areas.ver','Listar áreas de tramitação');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1270','admin.tramitacao.areas.criar','Criar áreas de tramitação');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1271','admin.tramitacao.areas.editar','Editar áreas de tramitação');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1272','admin.tramitacao.areas.apagar','Apagar áreas de tramitação');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1274','admin.documentos.ver_todos','Ver todos documentos');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1276','admin.tramitacao.encaminhar','Encaminhar Documento');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1277','admin.tramitacao.comentar','Comentar Documento');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1278','admin.tramitacao.estado','Estado do Documento');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1280','admin.documentos.arquivados.ver','Ver documentos arquivados');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1281','admin.documentos.arquivados.recuperar','Recuperar documentos arquivados');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1286','admin.documentos.arquivar','Arquivar documentos');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1288','admin.relatorios.ver','Relatórios');


-- Estrutura da tabela `recuperacao_password`
CREATE TABLE `recuperacao_password` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `utilizador_id` int unsigned NOT NULL,
  `token` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expira_em` datetime NOT NULL,
  `criado_em` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `utilizador_id` (`utilizador_id`),
  KEY `token` (`token`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- Estrutura da tabela `utilizadores`
CREATE TABLE `utilizadores` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `email` varchar(120) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `perfil_id` int NOT NULL,
  `ultimo_login` datetime DEFAULT NULL,
  `tentativas_falhadas` int DEFAULT '0',
  `ativo` tinyint(1) DEFAULT '1',
  `aprovado_por` int DEFAULT NULL,
  `aprovado_em` datetime DEFAULT NULL,
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=102 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dados da tabela `utilizadores`
INSERT INTO `utilizadores` (`id`,`nome`,`email`,`password`,`perfil_id`,`ultimo_login`,`tentativas_falhadas`,`ativo`,`aprovado_por`,`aprovado_em`,`criado_em`) VALUES ('2','Administrador','admin@admin.com','$2y$12$jPzCzZNPBbd5m33N6Xb4yeX5LVDZVXwp0rTC6aOHwTqAklgymf0.i','1','2026-04-06 20:01:05','0','1',NULL,'2026-04-07 17:10:28','2026-02-06 21:53:40');
INSERT INTO `utilizadores` (`id`,`nome`,`email`,`password`,`perfil_id`,`ultimo_login`,`tentativas_falhadas`,`ativo`,`aprovado_por`,`aprovado_em`,`criado_em`) VALUES ('3','Tony Almeida ','tony.almeida@anferalta.com','$2y$10$d3qcMm482tKiuS98CtBPW.gf1E3fJyB0bUY149NLBXnJ1RKVEDb.y','1','2026-04-06 19:04:43','0','1',NULL,'2026-04-07 17:10:18','2026-02-07 18:42:41');
INSERT INTO `utilizadores` (`id`,`nome`,`email`,`password`,`perfil_id`,`ultimo_login`,`tentativas_falhadas`,`ativo`,`aprovado_por`,`aprovado_em`,`criado_em`) VALUES ('92','MARIO SANTIAGO DE ALMEIDA','almeida.marius@gmail.com','$2y$12$fd4sQFtMsxOM44ADaT6NROfCZZuhSMyOSxdNlSUeCiVy8naET4zLy','3',NULL,'0','1','3','2026-09-04 16:10:50','2026-09-04 16:03:18');
INSERT INTO `utilizadores` (`id`,`nome`,`email`,`password`,`perfil_id`,`ultimo_login`,`tentativas_falhadas`,`ativo`,`aprovado_por`,`aprovado_em`,`criado_em`) VALUES ('93','Antonio Almeida','antonio.almeida@anferalta.com','$2y$12$.SXvviU40BMaDMJdMDFqO...8mfAoRc41LlFII9jVgX9xuD009TZu','4',NULL,'0','1','3','2026-09-04 17:06:49','2026-09-04 17:05:46');
INSERT INTO `utilizadores` (`id`,`nome`,`email`,`password`,`perfil_id`,`ultimo_login`,`tentativas_falhadas`,`ativo`,`aprovado_por`,`aprovado_em`,`criado_em`) VALUES ('94','Cristiano Caetano','cristianocaetanock10@gmail.com','$2y$12$Od8XbqrIQXtQEixk7/zaSuj7UHYRU5HOraMuOumViFY9x1A/tb9OO','3',NULL,'0','1','3','2026-09-06 00:53:45','2026-09-05 23:53:29');
INSERT INTO `utilizadores` (`id`,`nome`,`email`,`password`,`perfil_id`,`ultimo_login`,`tentativas_falhadas`,`ativo`,`aprovado_por`,`aprovado_em`,`criado_em`) VALUES ('95','antonio fernandes','anferalta@outlook.com','$2y$12$B3etjYAJUgW.jgSiuPNrXu8FNkE.0RF7YVBm5rIdMAgJJDrxA2Q86','9',NULL,'0','0','3','2026-09-17 20:05:59','2026-09-06 19:45:26');
INSERT INTO `utilizadores` (`id`,`nome`,`email`,`password`,`perfil_id`,`ultimo_login`,`tentativas_falhadas`,`ativo`,`aprovado_por`,`aprovado_em`,`criado_em`) VALUES ('96','Suporte','suporte@anferalta.com','$2y$12$AmLJ6FTPagrbHnwftwQRKuwSCgCwQiOdgRu9h62pJVkw/PPRmuPQe','2',NULL,'0','0',NULL,NULL,'2026-09-08 20:34:12');
INSERT INTO `utilizadores` (`id`,`nome`,`email`,`password`,`perfil_id`,`ultimo_login`,`tentativas_falhadas`,`ativo`,`aprovado_por`,`aprovado_em`,`criado_em`) VALUES ('97','Fernandes Almeida','anferalta@gmail.com','$2y$12$Nw6i2ShPcmUlWVl38cm4ROO6kV7P/cF58mFV1Fjt./lETuLwp838u','9',NULL,'0','1','3','2026-09-14 15:43:31','2026-09-14 15:41:01');
INSERT INTO `utilizadores` (`id`,`nome`,`email`,`password`,`perfil_id`,`ultimo_login`,`tentativas_falhadas`,`ativo`,`aprovado_por`,`aprovado_em`,`criado_em`) VALUES ('98','Daniel','daniel_almeida079@hotmail.com','$2y$12$W/4fmvWLdQToPdAB27FQyuypJkEJh0Jkm2PE1U1w588TPgecibs/a','4',NULL,'0','1','3','2026-09-15 18:37:57','2026-09-15 18:36:13');
INSERT INTO `utilizadores` (`id`,`nome`,`email`,`password`,`perfil_id`,`ultimo_login`,`tentativas_falhadas`,`ativo`,`aprovado_por`,`aprovado_em`,`criado_em`) VALUES ('99','Herberto','herbertosimoes64@gmail.com','$2y$12$NUu9OxJxLgtDKja/i6xXDu8twpE7e3qWr2TfuqKPfjwjA8oXhk8CS','4',NULL,'0','1','3','2026-09-15 19:15:11','2026-09-15 19:13:42');
INSERT INTO `utilizadores` (`id`,`nome`,`email`,`password`,`perfil_id`,`ultimo_login`,`tentativas_falhadas`,`ativo`,`aprovado_por`,`aprovado_em`,`criado_em`) VALUES ('100','Simarro','ljsdiamututa1@hotmail.com','$2y$12$BxyNXKmL5YEz3Q/tbuHq0OfXR9QVlHEZGh6NdC1fNiw9IppRV5F4m','4',NULL,'0','1','3','2026-09-15 20:31:55','2026-09-15 20:28:50');
INSERT INTO `utilizadores` (`id`,`nome`,`email`,`password`,`perfil_id`,`ultimo_login`,`tentativas_falhadas`,`ativo`,`aprovado_por`,`aprovado_em`,`criado_em`) VALUES ('101','Emilson dos Santos','hugahuga128@gmail.com','$2y$12$sJRpxnrN34bX1gkdx71CsOXwSNX9kXvix9kG94PlA5688DBx4lMJy','4',NULL,'0','1','3','2026-09-16 17:18:48','2026-09-16 15:50:42');


-- Estrutura da tabela `utilizadores_permissoes`
CREATE TABLE `utilizadores_permissoes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `utilizador_id` int NOT NULL,
  `permissao_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `utilizador_id` (`utilizador_id`),
  KEY `permissao_id` (`permissao_id`)
) ENGINE=MyISAM AUTO_INCREMENT=178 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dados da tabela `utilizadores_permissoes`
INSERT INTO `utilizadores_permissoes` (`id`,`utilizador_id`,`permissao_id`) VALUES ('165','2','0');
INSERT INTO `utilizadores_permissoes` (`id`,`utilizador_id`,`permissao_id`) VALUES ('166','2','0');
INSERT INTO `utilizadores_permissoes` (`id`,`utilizador_id`,`permissao_id`) VALUES ('167','2','0');
INSERT INTO `utilizadores_permissoes` (`id`,`utilizador_id`,`permissao_id`) VALUES ('168','2','0');
INSERT INTO `utilizadores_permissoes` (`id`,`utilizador_id`,`permissao_id`) VALUES ('169','2','12');
INSERT INTO `utilizadores_permissoes` (`id`,`utilizador_id`,`permissao_id`) VALUES ('170','2','13');
INSERT INTO `utilizadores_permissoes` (`id`,`utilizador_id`,`permissao_id`) VALUES ('171','3','12');
INSERT INTO `utilizadores_permissoes` (`id`,`utilizador_id`,`permissao_id`) VALUES ('172','3','13');
INSERT INTO `utilizadores_permissoes` (`id`,`utilizador_id`,`permissao_id`) VALUES ('173','1','1288');
INSERT INTO `utilizadores_permissoes` (`id`,`utilizador_id`,`permissao_id`) VALUES ('174','2','1276');
INSERT INTO `utilizadores_permissoes` (`id`,`utilizador_id`,`permissao_id`) VALUES ('175','2','1277');
INSERT INTO `utilizadores_permissoes` (`id`,`utilizador_id`,`permissao_id`) VALUES ('176','2','1278');
INSERT INTO `utilizadores_permissoes` (`id`,`utilizador_id`,`permissao_id`) VALUES ('177','2','1286');
