-- Backup gerado via PDO
-- Data: 2026-10-06 22:26:15



-- Estrutura da tabela `auditoria`
CREATE TABLE `auditoria` (
  `id` int NOT NULL AUTO_INCREMENT,
  `utilizador_id` int DEFAULT NULL,
  `acao` varchar(255) NOT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `detalhes` text,
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_auditoria_user` (`utilizador_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dados da tabela `auditoria`
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('1','93','login','95.92.125.33',NULL,'2026-10-06 21:18:59');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('2','93','login','95.92.125.33',NULL,'2026-10-06 21:36:05');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('3','93','login','95.92.125.33',NULL,'2026-10-06 21:57:33');
INSERT INTO `auditoria` (`id`,`utilizador_id`,`acao`,`ip`,`detalhes`,`criado_em`) VALUES ('4','93','logout','95.92.125.33',NULL,'2026-10-06 22:17:28');


-- Estrutura da tabela `auditoria_eliminacoes`
CREATE TABLE `auditoria_eliminacoes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tabela` varchar(100) NOT NULL,
  `acao` varchar(50) DEFAULT NULL,
  `registo_id` int NOT NULL,
  `dados` json NOT NULL,
  `apagado_por` int DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;



-- Estrutura da tabela `documento_areas`
CREATE TABLE `documento_areas` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `codigo` varchar(50) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  `criado_em` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `atualizado_em` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `prazo_resposta` int DEFAULT '3',
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dados da tabela `documento_areas`
INSERT INTO `documento_areas` (`id`,`nome`,`codigo`,`descricao`,`ativo`,`criado_em`,`atualizado_em`,`prazo_resposta`) VALUES ('1','Secretaria','SEC','Receção e distribuição de documentos','1','2026-04-18 21:00:15','2026-06-04 22:08:35','1');
INSERT INTO `documento_areas` (`id`,`nome`,`codigo`,`descricao`,`ativo`,`criado_em`,`atualizado_em`,`prazo_resposta`) VALUES ('2','Direção','DIR','Direção geral','1','2026-04-18 21:00:15','2026-06-06 13:34:26','5');
INSERT INTO `documento_areas` (`id`,`nome`,`codigo`,`descricao`,`ativo`,`criado_em`,`atualizado_em`,`prazo_resposta`) VALUES ('3','Financeira','FIN','Departamento financeiro','1','2026-04-18 21:00:15','2026-06-04 22:08:11','2');
INSERT INTO `documento_areas` (`id`,`nome`,`codigo`,`descricao`,`ativo`,`criado_em`,`atualizado_em`,`prazo_resposta`) VALUES ('4','Recursos Humanos','RH','Gestão de pessoal','1','2026-04-18 21:00:15','2026-06-04 22:09:18','2');
INSERT INTO `documento_areas` (`id`,`nome`,`codigo`,`descricao`,`ativo`,`criado_em`,`atualizado_em`,`prazo_resposta`) VALUES ('5','Arquivo','ARQ','Arquivo e documentação','1','2026-04-18 21:00:15','2026-07-22 19:55:44','3');
INSERT INTO `documento_areas` (`id`,`nome`,`codigo`,`descricao`,`ativo`,`criado_em`,`atualizado_em`,`prazo_resposta`) VALUES ('8','Gabinete Jurídico ','JUR','Gabinete jurídico ','1','2026-05-23 14:17:30','2026-06-04 22:09:45','2');


-- Estrutura da tabela `documento_estados`
CREATE TABLE `documento_estados` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordem` int unsigned NOT NULL DEFAULT '1',
  `final` tinyint(1) NOT NULL DEFAULT '0',
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_codigo` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dados da tabela `documento_estados`
INSERT INTO `documento_estados` (`id`,`codigo`,`nome`,`ordem`,`final`,`ativo`) VALUES ('15','novo','Novo','1','0','1');
INSERT INTO `documento_estados` (`id`,`codigo`,`nome`,`ordem`,`final`,`ativo`) VALUES ('16','pendente','Pendente','1','0','1');
INSERT INTO `documento_estados` (`id`,`codigo`,`nome`,`ordem`,`final`,`ativo`) VALUES ('17','em_tramitacao','Em Tramitação','1','0','1');
INSERT INTO `documento_estados` (`id`,`codigo`,`nome`,`ordem`,`final`,`ativo`) VALUES ('18','analise','Em Análise','1','0','1');
INSERT INTO `documento_estados` (`id`,`codigo`,`nome`,`ordem`,`final`,`ativo`) VALUES ('19','concluido','Concluído','1','0','1');
INSERT INTO `documento_estados` (`id`,`codigo`,`nome`,`ordem`,`final`,`ativo`) VALUES ('20','devolvido','Devolvido','1','0','1');
INSERT INTO `documento_estados` (`id`,`codigo`,`nome`,`ordem`,`final`,`ativo`) VALUES ('21','arquivado','Arquivado','1','0','1');


-- Estrutura da tabela `documento_ficheiros`
CREATE TABLE `documento_ficheiros` (
  `id` int NOT NULL AUTO_INCREMENT,
  `documento_id` int NOT NULL,
  `ficheiro` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ficheiro_original` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `caminho` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tamanho` int DEFAULT NULL,
  `mime_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hash` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `documento_id` (`documento_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- Estrutura da tabela `documento_tipos`
CREATE TABLE `documento_tipos` (
  `tipo_id` int unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  PRIMARY KEY (`tipo_id`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dados da tabela `documento_tipos`
INSERT INTO `documento_tipos` (`tipo_id`,`nome`) VALUES ('1','Carta');
INSERT INTO `documento_tipos` (`tipo_id`,`nome`) VALUES ('2','Ofício');
INSERT INTO `documento_tipos` (`tipo_id`,`nome`) VALUES ('3','Pedido');
INSERT INTO `documento_tipos` (`tipo_id`,`nome`) VALUES ('4','Relatório');
INSERT INTO `documento_tipos` (`tipo_id`,`nome`) VALUES ('5','Memorando');
INSERT INTO `documento_tipos` (`tipo_id`,`nome`) VALUES ('6','Circular');
INSERT INTO `documento_tipos` (`tipo_id`,`nome`) VALUES ('29','Exposiçao');
INSERT INTO `documento_tipos` (`tipo_id`,`nome`) VALUES ('35','Finanças');


-- Estrutura da tabela `documento_tramitacao`
CREATE TABLE `documento_tramitacao` (
  `id` int NOT NULL AUTO_INCREMENT,
  `documento_id` int NOT NULL,
  `utilizador_id` int NOT NULL,
  `acao` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `area_id` int DEFAULT NULL,
  `comentario` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `estado` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `criado_em` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `documento_id` (`documento_id`),
  KEY `utilizador_id` (`utilizador_id`),
  KEY `area_id` (`area_id`),
  KEY `estado` (`estado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- Estrutura da tabela `documento_tramitacao_anexos`
CREATE TABLE `documento_tramitacao_anexos` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `tramitacao_id` int unsigned NOT NULL,
  `ficheiro` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ficheiro_original` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `caminho` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tamanho` int DEFAULT NULL,
  `mime_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `tramitacao_id` (`tramitacao_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- Estrutura da tabela `documentos`
CREATE TABLE `documentos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tipo_id` int NOT NULL,
  `titulo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ficheiro` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `caminho` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ficheiro_original` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mime_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tamanho` int DEFAULT NULL,
  `hash` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `criado_por` int NOT NULL,
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP,
  `estado` tinyint(1) DEFAULT '1',
  `estado_atual` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'novo',
  `area_atual_id` int DEFAULT NULL,
  `arquivado_em` datetime DEFAULT NULL,
  `arquivado_por_id` int DEFAULT NULL,
  `area_atual_desde` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_documentos_utilizador` (`criado_por`),
  KEY `tipo_id` (`tipo_id`),
  KEY `fk_documentos_area_atual` (`area_atual_id`),
  KEY `fk_documentos_arquivado_por` (`arquivado_por_id`),
  KEY `fk_documentos_estado` (`estado_atual`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- Estrutura da tabela `documentos_arquivados`
CREATE TABLE `documentos_arquivados` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `documento_id` bigint unsigned NOT NULL,
  `ficheiro` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `caminho` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `mime_type` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `tamanho` int DEFAULT NULL,
  `arquivado_em` datetime NOT NULL,
  `arquivado_por` bigint unsigned DEFAULT NULL,
  `recuperado_em` datetime DEFAULT NULL,
  `recuperado_por` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `documento_id` (`documento_id`),
  CONSTRAINT `documentos_arquivados_ibfk_1` FOREIGN KEY (`documento_id`) REFERENCES `documentos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- Estrutura da tabela `documentos_logs`
CREATE TABLE `documentos_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `documento_id` int NOT NULL,
  `utilizador_id` int NOT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;



-- Estrutura da tabela `logs_sistema`
CREATE TABLE `logs_sistema` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tipo` varchar(50) NOT NULL,
  `mensagem` text NOT NULL,
  `ficheiro` varchar(255) DEFAULT NULL,
  `linha` int DEFAULT NULL,
  `detalhes` text,
  `ip` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `url` varchar(500) DEFAULT NULL,
  `metodo` varchar(10) DEFAULT NULL,
  `utilizador_id` int DEFAULT NULL,
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  FULLTEXT KEY `mensagem` (`mensagem`,`detalhes`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;



-- Estrutura da tabela `notificacoes`
CREATE TABLE `notificacoes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `utilizador_id` int unsigned NOT NULL,
  `documento_id` bigint unsigned DEFAULT NULL,
  `tipo` varchar(50) NOT NULL,
  `mensagem` text NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  `lida` tinyint(1) NOT NULL DEFAULT '0',
  `criado_em` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;



-- Estrutura da tabela `password_resets`
CREATE TABLE `password_resets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `criado_em` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `email` (`email`(250)),
  KEY `token` (`token`(250))
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dados da tabela `password_resets`
INSERT INTO `password_resets` (`id`,`email`,`token`,`criado_em`) VALUES ('1','almeida.marius@gmail.com','f6b81f455621e85cecbd3e89ba4a284ed0f3b19d995f3c2a939366ef99fc906c','2026-09-04 16:10:50');
INSERT INTO `password_resets` (`id`,`email`,`token`,`criado_em`) VALUES ('2','antonio.almeida@anferalta.com','67a2312d4af6acfdbe11d84767fbdfc75486d584c7d7ec47a9d504b92ebb8492','2026-09-04 17:06:49');
INSERT INTO `password_resets` (`id`,`email`,`token`,`criado_em`) VALUES ('3','cristianocaetanock10@gmail.com','06297212f9abd18670c3d3b4ffed84e22c2b979661186b12f49d6b650c78c447','2026-09-06 00:53:45');
INSERT INTO `password_resets` (`id`,`email`,`token`,`criado_em`) VALUES ('4','anferalta@gmail.com','80670924dbe9125e533efcfa3dfeab9e76a792c3c6d18ad43b733227ad118af2','2026-09-14 15:43:31');
INSERT INTO `password_resets` (`id`,`email`,`token`,`criado_em`) VALUES ('5','daniel_almeida079@hotmail.com','58df7886feafcf7cc61572841a14cfaaf75d544f80cbed3a39d112adaad90982','2026-09-15 18:37:57');
INSERT INTO `password_resets` (`id`,`email`,`token`,`criado_em`) VALUES ('6','herbertosimoes64@gmail.com','b7f4f971ebaca7f530eef484a28480723fbf4b0fe73fdd939ef8787cb17044c8','2026-09-15 19:15:11');
INSERT INTO `password_resets` (`id`,`email`,`token`,`criado_em`) VALUES ('7','ljsdiamututa1@hotmail.com','3fe006e4912f5e020cd4fb132a7a2b4a498b8caa1f314c00636cd1822a959b99','2026-09-15 20:31:55');
INSERT INTO `password_resets` (`id`,`email`,`token`,`criado_em`) VALUES ('8','hugahuga128@gmail.com','81334d307f7a2bcdf332d71ab4aa4d5e99aab8dc379acb0b900aca7157ca664e','2026-09-16 17:18:48');
INSERT INTO `password_resets` (`id`,`email`,`token`,`criado_em`) VALUES ('9','anferalta@outlook.com','57570c1ed1f920c032800acc41b93ffe21763afe40d6dae37febfe6a88fc46b1','2026-09-17 20:05:59');
INSERT INTO `password_resets` (`id`,`email`,`token`,`criado_em`) VALUES ('10','felismarcardoso09@gmail.com','5d75500a163eace7fce81a1286cbf6bc05d382395729190d7eb5a17f3103cb96','2026-09-24 12:07:41');
INSERT INTO `password_resets` (`id`,`email`,`token`,`criado_em`) VALUES ('11','mateusgapa01@hotmail.com','d04fdaeb1f4aaf353b47ea1b2de7e72b1291010ed5bac3803396959ed18c6707','2026-09-25 15:35:36');


-- Estrutura da tabela `perfis`
CREATE TABLE `perfis` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  `criado_em` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nome` (`nome`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dados da tabela `perfis`
INSERT INTO `perfis` (`id`,`nome`,`descricao`,`ativo`,`criado_em`) VALUES ('1','admin','Administrador do sistema','1','2026-02-17 18:03:49');
INSERT INTO `perfis` (`id`,`nome`,`descricao`,`ativo`,`criado_em`) VALUES ('3','Gestor','Gestor de Sistema','1','2026-02-24 20:23:10');
INSERT INTO `perfis` (`id`,`nome`,`descricao`,`ativo`,`criado_em`) VALUES ('4','Utilizador','Utilizador de Sistema','1','2026-02-24 20:36:31');
INSERT INTO `perfis` (`id`,`nome`,`descricao`,`ativo`,`criado_em`) VALUES ('9','Supervisor','Supervisor de Sistema','1','2026-02-25 14:00:35');


-- Estrutura da tabela `perfis_permissoes`
CREATE TABLE `perfis_permissoes` (
  `perfil_id` int NOT NULL,
  `permissao_id` int NOT NULL,
  PRIMARY KEY (`perfil_id`,`permissao_id`),
  KEY `fk_permissao` (`permissao_id`),
  CONSTRAINT `fk_perfil` FOREIGN KEY (`perfil_id`) REFERENCES `perfis` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_permissao` FOREIGN KEY (`permissao_id`) REFERENCES `permissoes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dados da tabela `perfis_permissoes`
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1183');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1183');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1183');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1184');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1184');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1184');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1185');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1186');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1187');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1188');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1189');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1190');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1191');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1192');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1193');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1194');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1195');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1196');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1197');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1198');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1198');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1198');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1199');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1199');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1199');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1200');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1201');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1202');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1203');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1204');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1205');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1205');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1205');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1206');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1206');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1206');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1207');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1208');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1209');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1209');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1210');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1211');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1211');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('4','1211');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1211');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1212');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('4','1212');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1213');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('4','1213');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1213');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1214');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('4','1214');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1215');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('4','1215');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1215');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1216');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1217');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1218');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1219');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1220');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1220');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1220');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1221');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1222');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1222');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1222');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1223');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1224');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1225');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1225');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1226');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1227');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1227');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1228');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1229');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1229');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1236');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1236');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1237');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1267');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1267');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1267');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1268');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1268');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1268');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1269');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1270');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1271');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1272');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1274');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1274');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1274');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1276');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1276');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1276');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1277');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1277');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1277');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1278');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1278');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1278');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1280');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1280');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1280');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1281');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1286');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('1','1288');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('3','1288');
INSERT INTO `perfis_permissoes` (`perfil_id`,`permissao_id`) VALUES ('9','1288');


-- Estrutura da tabela `permissoes`
CREATE TABLE `permissoes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `codigo` varchar(100) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=1291 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dados da tabela `permissoes`
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1183','admin.dashboard.ver','Aceder ao dashboard');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1184','admin.utilizadores.ver','Listar utilizadores');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1185','admin.utilizadores.criar','Criar utilizadores');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1186','admin.utilizadores.editar','Editar utilizadores');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1187','admin.utilizadores.apagar','Apagar utilizadores');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1188','admin.perfis.ver','Listar perfis');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1189','admin.perfis.criar','Criar perfis');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1190','admin.perfis.editar','Editar perfis');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1191','admin.perfis.apagar','Apagar perfis');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1192','admin.perfis.permissoes','Gerir permissões do perfil');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1193','admin.permissoes.ver','Listar permissões');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1194','admin.permissoes.criar','Criar permissões');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1195','admin.permissoes.editar','Editar permissões');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1196','admin.permissoes.apagar','Apagar permissões');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1197','admin.permissoes.sincronizar','Sincronizar permissões');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1198','admin.backups.bd.ver','Ver backups da base de dados');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1199','admin.backups.bd.criar','Criar backup da base de dados');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1200','admin.backups.bd.download','Descarregar backup da base de dados');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1201','admin.backups.bd.apagar','Apagar backup da base de dados');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1202','admin.backups.bd.restaurar','Restaurar backup da base de dados');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1203','admin.backups.bd.restaurar.confirmar','Confirmar restauro da base de dados');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1204','admin.backups.bd.restaurar.executar','Executar restauro da base de dados');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1205','admin.backups.files.ver','Ver backups de ficheiros');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1206','admin.backups.files.criar','Criar backup de ficheiros');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1207','admin.backups.files.download','Descarregar backup de ficheiros');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1208','admin.backups.files.apagar','Apagar backup de ficheiros');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1209','admin.backups.agendamentos.ver','Ver agendamentos de backups');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1210','admin.backups.agendamentos.editar','Editar agendamentos de backups');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1211','admin.documentos.ver','Listar documentos');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1212','admin.documentos.criar','Criar documentos');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1213','admin.documentos.editar','Editar documentos');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1214','admin.documentos.apagar','Apagar documentos');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1215','admin.documentos.download','Descarregar documentos');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1216','admin.documento-tipos.ver','Listar tipos de documento');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1217','admin.documento-tipos.criar','Criar tipos de documento');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1218','admin.documento-tipos.editar','Editar tipos de documento');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1219','admin.documento-tipos.apagar','Apagar tipos de documento');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1220','admin.logs.ver','Ver logs do sistema');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1221','admin.logs.apagar','Apagar logs do sistema');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1222','admin.auditoria.ver','Ver auditoria do sistema');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1223','admin.config.ver','Ver configurações');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1224','admin.config.editar','Editar configurações');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1225','documentos.ver','Ver documentos');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1226','documentos.criar','Criar documentos');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1227','documentos.editar','Editar documentos');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1228','documentos.apagar','Apagar documentos');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1229','documentos.download','Descarregar documentos');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1236','admin.utilizadores.aprovar','Aprovar utilizadores');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1237','admin.utilizadores.bloquear','Bloquear utilizadores');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1267','admin.tramitacao.ver','Aceder à tramitação');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1268','admin.tramitacao.dashboard','Ver dashboard de tramitação');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1269','admin.tramitacao.areas.ver','Listar áreas de tramitação');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1270','admin.tramitacao.areas.criar','Criar áreas de tramitação');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1271','admin.tramitacao.areas.editar','Editar áreas de tramitação');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1272','admin.tramitacao.areas.apagar','Apagar áreas de tramitação');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1274','admin.documentos.ver_todos','Ver todos documentos');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1276','admin.tramitacao.encaminhar','Encaminhar Documento');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1277','admin.tramitacao.comentar','Comentar Documento');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1278','admin.tramitacao.estado','Estado do Documento');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1280','admin.documentos.arquivados.ver','Ver documentos arquivados');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1281','admin.documentos.arquivados.recuperar','Recuperar documentos arquivados');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1286','admin.documentos.arquivar','Arquivar documentos');
INSERT INTO `permissoes` (`id`,`codigo`,`descricao`) VALUES ('1288','admin.relatorios.ver','Relatórios');


-- Estrutura da tabela `recuperacao_password`
CREATE TABLE `recuperacao_password` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `utilizador_id` int unsigned NOT NULL,
  `token` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expira_em` datetime NOT NULL,
  `criado_em` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `utilizador_id` (`utilizador_id`),
  KEY `token` (`token`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



-- Estrutura da tabela `utilizadores`
CREATE TABLE `utilizadores` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `email` varchar(120) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `perfil_id` int NOT NULL,
  `ultimo_login` datetime DEFAULT NULL,
  `tentativas_falhadas` int DEFAULT '0',
  `ativo` tinyint(1) DEFAULT '1',
  `aprovado_por` int DEFAULT NULL,
  `aprovado_em` datetime DEFAULT NULL,
  `criado_em` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dados da tabela `utilizadores`
INSERT INTO `utilizadores` (`id`,`nome`,`email`,`password`,`perfil_id`,`ultimo_login`,`tentativas_falhadas`,`ativo`,`aprovado_por`,`aprovado_em`,`criado_em`) VALUES ('2','Administrador','admin@admin.com','$2y$12$jPzCzZNPBbd5m33N6Xb4yeX5LVDZVXwp0rTC6aOHwTqAklgymf0.i','1','2026-04-06 20:01:05','0','1',NULL,'2026-04-07 17:10:28','2026-02-06 21:53:40');
INSERT INTO `utilizadores` (`id`,`nome`,`email`,`password`,`perfil_id`,`ultimo_login`,`tentativas_falhadas`,`ativo`,`aprovado_por`,`aprovado_em`,`criado_em`) VALUES ('3','Tony Almeida ','tony.almeida@anferalta.com','$2y$10$d3qcMm482tKiuS98CtBPW.gf1E3fJyB0bUY149NLBXnJ1RKVEDb.y','1','2026-04-06 19:04:43','0','1',NULL,'2026-04-07 17:10:18','2026-02-07 18:42:41');
INSERT INTO `utilizadores` (`id`,`nome`,`email`,`password`,`perfil_id`,`ultimo_login`,`tentativas_falhadas`,`ativo`,`aprovado_por`,`aprovado_em`,`criado_em`) VALUES ('92','MARIO SANTIAGO DE ALMEIDA','almeida.marius@gmail.com','$2y$12$fd4sQFtMsxOM44ADaT6NROfCZZuhSMyOSxdNlSUeCiVy8naET4zLy','3',NULL,'0','1','3','2026-09-04 16:10:50','2026-09-04 16:03:18');
INSERT INTO `utilizadores` (`id`,`nome`,`email`,`password`,`perfil_id`,`ultimo_login`,`tentativas_falhadas`,`ativo`,`aprovado_por`,`aprovado_em`,`criado_em`) VALUES ('93','Antonio Almeida','antonio.almeida@anferalta.com','$2y$12$.SXvviU40BMaDMJdMDFqO...8mfAoRc41LlFII9jVgX9xuD009TZu','4',NULL,'0','1','3','2026-09-04 17:06:49','2026-09-04 17:05:46');
INSERT INTO `utilizadores` (`id`,`nome`,`email`,`password`,`perfil_id`,`ultimo_login`,`tentativas_falhadas`,`ativo`,`aprovado_por`,`aprovado_em`,`criado_em`) VALUES ('94','Cristiano Caetano','cristianocaetanock10@gmail.com','$2y$12$Od8XbqrIQXtQEixk7/zaSuj7UHYRU5HOraMuOumViFY9x1A/tb9OO','3',NULL,'0','1','3','2026-09-06 00:53:45','2026-09-05 23:53:29');
INSERT INTO `utilizadores` (`id`,`nome`,`email`,`password`,`perfil_id`,`ultimo_login`,`tentativas_falhadas`,`ativo`,`aprovado_por`,`aprovado_em`,`criado_em`) VALUES ('95','antonio fernandes','anferalta@outlook.com','$2y$12$B3etjYAJUgW.jgSiuPNrXu8FNkE.0RF7YVBm5rIdMAgJJDrxA2Q86','9',NULL,'0','0','3','2026-09-17 20:05:59','2026-09-06 19:45:26');
INSERT INTO `utilizadores` (`id`,`nome`,`email`,`password`,`perfil_id`,`ultimo_login`,`tentativas_falhadas`,`ativo`,`aprovado_por`,`aprovado_em`,`criado_em`) VALUES ('96','Suporte','suporte@anferalta.com','$2y$12$AmLJ6FTPagrbHnwftwQRKuwSCgCwQiOdgRu9h62pJVkw/PPRmuPQe','2',NULL,'0','0',NULL,NULL,'2026-09-08 20:34:12');
INSERT INTO `utilizadores` (`id`,`nome`,`email`,`password`,`perfil_id`,`ultimo_login`,`tentativas_falhadas`,`ativo`,`aprovado_por`,`aprovado_em`,`criado_em`) VALUES ('97','Fernandes Almeida','anferalta@gmail.com','$2y$12$Nw6i2ShPcmUlWVl38cm4ROO6kV7P/cF58mFV1Fjt./lETuLwp838u','9',NULL,'0','1','3','2026-09-14 15:43:31','2026-09-14 15:41:01');
INSERT INTO `utilizadores` (`id`,`nome`,`email`,`password`,`perfil_id`,`ultimo_login`,`tentativas_falhadas`,`ativo`,`aprovado_por`,`aprovado_em`,`criado_em`) VALUES ('98','Daniel','daniel_almeida079@hotmail.com','$2y$12$W/4fmvWLdQToPdAB27FQyuypJkEJh0Jkm2PE1U1w588TPgecibs/a','4',NULL,'0','1','3','2026-09-15 18:37:57','2026-09-15 18:36:13');
INSERT INTO `utilizadores` (`id`,`nome`,`email`,`password`,`perfil_id`,`ultimo_login`,`tentativas_falhadas`,`ativo`,`aprovado_por`,`aprovado_em`,`criado_em`) VALUES ('99','Herberto','herbertosimoes64@gmail.com','$2y$12$NUu9OxJxLgtDKja/i6xXDu8twpE7e3qWr2TfuqKPfjwjA8oXhk8CS','4',NULL,'0','1','3','2026-09-15 19:15:11','2026-09-15 19:13:42');
INSERT INTO `utilizadores` (`id`,`nome`,`email`,`password`,`perfil_id`,`ultimo_login`,`tentativas_falhadas`,`ativo`,`aprovado_por`,`aprovado_em`,`criado_em`) VALUES ('100','Simarro','ljsdiamututa1@hotmail.com','$2y$12$BxyNXKmL5YEz3Q/tbuHq0OfXR9QVlHEZGh6NdC1fNiw9IppRV5F4m','4',NULL,'0','1','3','2026-09-15 20:31:55','2026-09-15 20:28:50');
INSERT INTO `utilizadores` (`id`,`nome`,`email`,`password`,`perfil_id`,`ultimo_login`,`tentativas_falhadas`,`ativo`,`aprovado_por`,`aprovado_em`,`criado_em`) VALUES ('101','Emilson dos Santos','hugahuga128@gmail.com','$2y$12$sJRpxnrN34bX1gkdx71CsOXwSNX9kXvix9kG94PlA5688DBx4lMJy','4',NULL,'0','1','3','2026-09-16 17:18:48','2026-09-16 15:50:42');
INSERT INTO `utilizadores` (`id`,`nome`,`email`,`password`,`perfil_id`,`ultimo_login`,`tentativas_falhadas`,`ativo`,`aprovado_por`,`aprovado_em`,`criado_em`) VALUES ('102','Felismar Cardoso','felismarcardoso09@gmail.com','$2y$12$wiBpxpJa5UofUN4PvonbLu/BodsvfU6.FIbxrKCIBH4wZOJeJeSem','4',NULL,'0','1','3','2026-09-24 12:07:41','2026-09-23 23:39:02');
INSERT INTO `utilizadores` (`id`,`nome`,`email`,`password`,`perfil_id`,`ultimo_login`,`tentativas_falhadas`,`ativo`,`aprovado_por`,`aprovado_em`,`criado_em`) VALUES ('103','Mateus Santiago','mateusgapa01@hotmail.com','$2y$12$rBRrJKJyzF0HQk7FlCHkMe3YJwF/K/B7Ouci/tHMPdwGHOMi6sSHG','4',NULL,'0','1','3','2026-09-25 15:35:36','2026-09-25 15:33:10');


-- Estrutura da tabela `utilizadores_permissoes`
CREATE TABLE `utilizadores_permissoes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `utilizador_id` int NOT NULL,
  `permissao_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `utilizador_id` (`utilizador_id`),
  KEY `permissao_id` (`permissao_id`)
) ENGINE=MyISAM AUTO_INCREMENT=178 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dados da tabela `utilizadores_permissoes`
INSERT INTO `utilizadores_permissoes` (`id`,`utilizador_id`,`permissao_id`) VALUES ('165','2','0');
INSERT INTO `utilizadores_permissoes` (`id`,`utilizador_id`,`permissao_id`) VALUES ('166','2','0');
INSERT INTO `utilizadores_permissoes` (`id`,`utilizador_id`,`permissao_id`) VALUES ('167','2','0');
INSERT INTO `utilizadores_permissoes` (`id`,`utilizador_id`,`permissao_id`) VALUES ('168','2','0');
INSERT INTO `utilizadores_permissoes` (`id`,`utilizador_id`,`permissao_id`) VALUES ('169','2','12');
INSERT INTO `utilizadores_permissoes` (`id`,`utilizador_id`,`permissao_id`) VALUES ('170','2','13');
INSERT INTO `utilizadores_permissoes` (`id`,`utilizador_id`,`permissao_id`) VALUES ('171','3','12');
INSERT INTO `utilizadores_permissoes` (`id`,`utilizador_id`,`permissao_id`) VALUES ('172','3','13');
INSERT INTO `utilizadores_permissoes` (`id`,`utilizador_id`,`permissao_id`) VALUES ('173','1','1288');
INSERT INTO `utilizadores_permissoes` (`id`,`utilizador_id`,`permissao_id`) VALUES ('174','2','1276');
INSERT INTO `utilizadores_permissoes` (`id`,`utilizador_id`,`permissao_id`) VALUES ('175','2','1277');
INSERT INTO `utilizadores_permissoes` (`id`,`utilizador_id`,`permissao_id`) VALUES ('176','2','1278');
INSERT INTO `utilizadores_permissoes` (`id`,`utilizador_id`,`permissao_id`) VALUES ('177','2','1286');
